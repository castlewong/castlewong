//
//  DynamicFilteredForSearchView.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/16.
//

import SwiftUI
import CoreData

struct DynamicFilteredForSearchView<Content: View, S>: View where S: NSManagedObject {
    
//    @Binding var searchText: String = ""
    
    // MARK: core data request
    @FetchRequest var request: FetchedResults<S>
    let content: (S) -> Content
    
    // MARK: Imitating Kavsoft to Build custom foreach which will give core data object to build view
    // replace Date to String
        init(dataToFilter: String, @ViewBuilder content: @escaping (S) -> Content){
    
    // Filter key
            
            let query = dataToFilter
    
    // MARK: predicate to filter current data tasks
            let predicate = NSPredicate(format: "taskDescription CONTAINS[c] %@", query)
    
            // Intializing request with NSPredicate
            // Adding sort
            _request = FetchRequest(entity: S.entity(), sortDescriptors: [.init(keyPath: \Task.taskDate, ascending: true)], predicate: predicate)
            self.content = content
            
        }
    
    
    //    var body: some View {
    //        ForEach(request, id: \.objectID){ object in
    //            self.content(object)
    //        }
    //
    //    }
    
    
    var body: some View {
        
        Group{
            if request.isEmpty{
                Text("How do you feel?")
                    .font(.system(size: 26))
                    .fontWeight(.medium)
                    .offset(y: 200)
                    .foregroundColor(.gray.opacity(0.7))
            } else {
                ForEach(request, id: \.objectID){object in
                    self.content(object)
                }
            }
        }

    }
    
}
