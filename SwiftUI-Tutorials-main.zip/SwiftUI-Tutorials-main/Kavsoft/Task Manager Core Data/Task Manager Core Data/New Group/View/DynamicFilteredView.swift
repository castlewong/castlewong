//
//  DynamicFilteredView.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/2.
//

// Filter function seems not confer to this condiction

import SwiftUI
import CoreData

struct DynamicFilteredView<Content: View, T>: View where T: NSManagedObject {
    // MARK: core data request
    @FetchRequest var request: FetchedResults<T>
    let content: (T)->Content
    
    // MARK: Building custom foreach which will give core data object to build view
    init(dateToFilter: Date, @ViewBuilder content: @escaping (T) -> Content){
        
        // MARK: predicate to filter current date tasks
        let calendar = Calendar.current
        
        let today = calendar.startOfDay(for: dateToFilter)
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: today)!
        
        // Filter key
        let filterKey = "taskDate"
        
        let predicate = NSPredicate(format: "\(filterKey) >= %@ AND \(filterKey) < %@", argumentArray: [today, tomorrow])
        
        
        // Intializing request with NSPredicate
        // Adding sort
        _request = FetchRequest(entity: T.entity(), sortDescriptors: [.init(keyPath: \Task.taskDate, ascending: true)], predicate: predicate)
        self.content = content
    }
    
    var body: some View {
        
        Group{
            if request.isEmpty{
                Text("How do you feel?")
                    .font(.system(size: 26))
                    .fontWeight(.medium)
                    .offset(y: 200)
                    .foregroundColor(.gray.opacity(0.7))
//                    .environment(\.locale, .init(identifier: "zh-Hans"))
            } else {
                ForEach(request, id: \.objectID){object in
                    self.content(object)
                }
            }
        }
    }
}

