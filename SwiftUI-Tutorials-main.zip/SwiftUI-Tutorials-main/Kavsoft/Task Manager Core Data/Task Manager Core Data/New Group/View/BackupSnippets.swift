//
//  BackupSnippets.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/16.
//

// dots
//                                    Circle()
//                                        .fill(.white)
//                                        .frame(width: 8, height: 8)
//                                        .opacity(taskModel.isToday(date: day) ? 1 : 0)

// EEE will return day as MON, TUE, ...
//                                Text(day.formatted(date: .abbreviated, time: .omitted))


//            Image(systemName: "plus")
//                .foregroundColor(.white)
//                .padding()
//                .background(Color.black, in: Circle())


// MARK: try search view
// MARK: 搜索栏
//    func searchBarView() -> some View {
//        TextField("搜索内容", text: $taskModel.searchText)
//            .padding(7)
//            .padding(.horizontal, 25)
//            .background(Color(.systemGray6))
//            .cornerRadius(8)
//            .overlay(
//                HStack {
//                    Image(systemName: "magnifyingglass")
//                        .foregroundColor(.gray)
//                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
//                        .padding(.leading, 8)
//
//                    // 编辑时显示清除按钮
//                    if taskModel.searchText != "" {
//                        Button(action: {
//                            self.taskModel.searchText = ""
//                            self.taskModel.loadItems()
//                        }) {
//                            Image(systemName: "multiply.circle.fill")
//                                .foregroundColor(.gray)
//                                .padding(.trailing, 8)
//                        }
//                    }
//                }
//            )
//            .padding(.horizontal, 10)
//            .onChange(of: taskModel.searchText) { _ in
//                if taskModel.searchText != "" {
//                    self.taskModel.isSearching = true
//                    // searchContent() 是搜索笔记的函数
////                    self.taskModel.searchContet()
//                } else {
//                    taskModel.searchText = ""
//                    self.taskModel.isSearching = false
//                    self.taskModel.loadItems()
//                }
//            }
//    }

// current month view
//                        DatePicker("🗓️", selection: $taskModel.currentDay)
//                        DatePicker("Sel", selection: $taskModel.currentDay, displayedComponents: [.date])

//
//NavigationView{
//    List(request) { result in
//        Text(request.taskTitle)
//    }
//}
//.searchable(text: $query, prompt: "Search Content")
//.onChange(of: query) { newValue in
//    request.nsPredicate = searchPredicate(query: newValue)
//}
//
//func searchPredicate(query: String) -> NSPredicate? {
//    if query.isEmpty { return nil }
//    return NSPredicate(format: "taskDescription CONTAINS[c] %@", query)
//}



// 2023年01月07日 星期六
// 备份 image picker
//
//struct ImagePicker: UIViewControllerRepresentable {
//    
//    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
//        let picker = UIImagePickerController()
//        picker.delegate = context.coordinator
//        return picker
//    }
//
//    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {
//
//    }
//
//    // MARK: - Environment Object
//    @Environment(\.managedObjectContext) var presentationMode
//    @Environment(\.dismiss) var dismiss
//    @Binding var image: UIImage?
//
//    // MARK: - Coordinator Class
//    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
//        let parent: ImagePicker
//
//        init(_ parent: ImagePicker) {
//            self.parent = parent
//        }
//
//        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
//            if let uiImage = info[.originalImage] as? UIImage {
//                parent.image = uiImage
//            }
//            parent.dismiss()
//        }
//    }
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self)
//    }
//
//
//}
//
////My SwiftUI Form where i select the image and save it in CoreData
//struct ImageToCoreData: View {
//    
//    @EnvironmentObject var taskModel: TaskViewModel
//
//    // Image
//    @State private var image: Image?
//    @State private var showImagePicker = false
//    @State private var inputImage: UIImage?
//    @Environment(\.managedObjectContext) var context
//
//    func save() {
//        
//        let task = Task(context: context)
//        let pickedImage = inputImage?.jpegData(compressionQuality: 1.0)
//        task.taskImage = pickedImage
//
//        do {
//            // saving
//            try context.save()
//            print("item of memo is saved")
//        } catch {
//            print(error.localizedDescription)
//        }
//        //  Save to Core Data
//        
//    }
//    
//    func loadImage() {
//        guard let inputImage = inputImage else { return }
//        image = Image(uiImage: inputImage)
//    }
//    
//    // MARK: - Body
//    var body: some View {
//        
//        // MARK: - Return View
////        return NavigationView {
//            VStack {
//                // Section Picture
////                Section(header: Text("Picture", comment: "Section Header - Picture")) {
//                    if image != nil {
//                        image!
//                            .resizable()
//                            .scaledToFit()
//                            .cornerRadius(12)
//                            .onTapGesture { self.showImagePicker.toggle() }
//                    } else {
//                        Button(action: { self.showImagePicker.toggle() }) {
//                            Text("Select Image", comment: "Select Image Button")
//                                .accessibility(identifier: "Select Image")
//                        }
//                    }
////                }
//                
//                // Section Save / Reset
//                VStack {
//                    Button() {
//                        save()
//                    } label: {
//                        Text("Save")
//                    }
////                    Button(action: save) {
////                        Text("Save", comment: "Save Button")
////                    }
//                }
//            }
//            .sheet(isPresented: $showImagePicker, onDismiss: loadImage) { ImagePicker2(image: self.$inputImage) }
////        }
//    }
//}

// 2023年01月09日 星期一 2023-01-09 03:54:37
//https://pratheeshbennet.medium.com/core-data-managed-objects-to-csv-950beddc81e9
//func csv(withManagedObejcts arrManagedObjects:[Task]){
//    var CSVString = "Des, Date\n"
//    arrManagedObjects.forEach { (eachObject) in
//        let entityContent = "\(String(describing: eachObject.taskDescription)),\(String(describing: eachObject.taskDate))\n"
//        CSVString.append(entityContent)
//    }
//    let fileManager = FileManager.default
//    let directory = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
//    let path = directory.appendingPathComponent("Task").appendingPathExtension("csv")
//    if(!fileManager.fileExists(atPath: path.path)){
//        fileManager.createFile(atPath: path.path, contents: nil, attributes: nil)
//    }
//    do {
//        try CSVString.write(to: path, atomically: true, encoding: .utf8)
//    } catch let error {
//        print("Error creating CSV \(error.localizedDescription)")
//    }
//}

// 2023-01-09 04:13:23 https://youtu.be/LNKnChO5aPc
// https://youtu.be/rM_2i5YobF4
//func ShareMemory(Info: String) {
//    let InfoU = Info
//    let av = UIActivityViewController(activityItems: [InfoU], applicationActivities: nil)
//    UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
//}
