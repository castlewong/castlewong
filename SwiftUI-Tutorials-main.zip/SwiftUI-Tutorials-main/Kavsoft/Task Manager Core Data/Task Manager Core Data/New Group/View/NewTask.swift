//
//  NewTask.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/2.
//

import SwiftUI
//import UIKit

struct NewTask: View {
    // try 2023-01-13 23:00:02
    @Namespace var animation
    
    // MARK: try view to image 2023-01-12 23:41:31
    @State private var showingImageView = false
    
    // MARK: try imageToData 2023-01-07 20:16:52
    @State private var image: Image?
    @State private var showImagePicker = false
    @State private var inputImage: UIImage?
    
    @Environment(\.dismiss) var dismiss
    
    // MARK: try taskImage
//    @State var imageOfMemo: UIImage?
    @FocusState var keyBoardFocused: Bool
    
    // MARK: task value
    @State var taskTitle: String = ""
    @State var taskDescription: String = ""
    @State var taskDate: Date = Date()
    // MARK: Make a try 2022-12-05 22:35:18 怒哀乐厌惧 悲喜怒厌惧 喜怒哀厌惧
    @State var taskColor: String = ""


    // MARK: Core data context
    @Environment(\.managedObjectContext) var context
    
    @EnvironmentObject var taskModel: TaskViewModel
    
    var testView: some View{
        VStack{
            Text(taskDescription)
                .padding()
                .background(.blue)
                .foregroundColor(.white)
                .clipShape(Capsule())
            Text(taskDate.formatted(date: .omitted, time: .shortened))
                .padding()
                .background(.blue)
                .foregroundColor(.white)
                .clipShape(Capsule())
            if image != nil {
                image!
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(12)
                    .padding(.bottom)
                    .cornerRadius(12)

            } else {}
            Spacer()
        }
    }
    
    var body: some View {
        if taskModel.showSAIview {
            SaveAsImage(textDes: taskDescription, textDate: taskDate)
        } else {
            NavigationView{
                ScrollView(.vertical, showsIndicators: false){
                    VStack(alignment: .leading){
                        //                    TextField("Plz1", text: $taskTitle)
                        //                        .padding()
                        //                        .background(Color.gray.opacity(0.1))
                        //                        .cornerRadius(8)
                        //                    .textFieldStyle(RoundedBorderTextFieldStyle())
                        //                    .padding(.bottom)
                        //                    .font(.system(size: 17))
                        //                    .frame(height: 100, alignment: .topLeading)
                        //                    .background(Color.gray.opacity(0.2))
                        //                    .cornerRadius(12)
                        //                    .padding(.horizontal, 16)
                        //                    testView
                        //                    Button("Save as image") {
                        //                        let image = testView.snapshot()
                        //                        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                        //                    }
                        //                    NavigationView{
                        //                        NavigationLink(destination: SaveAsImage(textDes: taskDescription, textDate: taskDate)) {
                        //                            Text("2")
                        //                        }
                        //                    }
                        //                    Button(action: {
                        ////                            ShareMemory(Info: String("taskModel.currentDay")) // func works
                        ////                            csv(withManagedObejcts: [Task]
                        //                        showingImageView.toggle()
                        //                    }, label: {
                        //                        Image(systemName: "photo.stack.fill")
                        //                    })
                        //                    .sheet(isPresented: $showingImageView) {
                        //
                        //                    } content: {
                        //                        SaveAsImage(textDes: taskDescription, textDate: taskDate)
                        //                    }
                        VStack{
                            Button(action: {
                                taskModel.showSAIview.toggle()
                            }, label: {
                                Image(systemName: "photo.stack.fill")
                            })
                        }
                        .onTapGesture {
                            withAnimation {
//                                taskModel.showSAIview.toggle()
                            }
                        }
                        TextField("Plz2", text: $taskDescription)
                            .focused($keyBoardFocused)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                            .toolbar{
                                ToolbarItemGroup(placement: .keyboard) {
                                    Button(){
//                                        dismiss()
                                        taskModel.currentColor = ""
                                        withAnimation {
                                            
                                            taskModel.addNewTask.toggle()
                                        }
                                    } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.gray)
                                    }
                                    Button(){
                                        // simple create a new entity object with context and set the values for the object and finally save the context, this will create a new object in our core data
                                        if let task = taskModel.editTask{
                                            task.taskTitle = taskTitle
                                            task.taskDescription = taskDescription
                                            task.taskColor = taskColor
                                            // MARK: try save image
                                            
                                        } else {
                                            let task = Task(context: context)
                                            task.taskTitle = taskTitle
                                            task.taskDescription = taskDescription
                                            task.taskDate = taskDate
                                            task.taskColor = taskColor
                                            task.taskImage = inputImage?.jpegData(compressionQuality: 1.0)
                                        }
                                        
                                        do {
                                            // saving
                                            try context.save()
                                            print("item of memo is saved")
                                            taskModel.currentColor = ""
                                        } catch {
                                            print(error.localizedDescription)
                                        }
                                        // Dismissing view
                                        taskModel.addNewTask.toggle()
//                                        dismiss()
                                        taskModel.currentColor = ""
                                    } label: {
                                        Image(systemName: "square.and.arrow.down.fill")
                                            .foregroundColor(.gray)
                                    }
                                }
                            }
                        //                    .padding(.bottom)
                        // original imagetodata
                        VStack {
                            // Section Picture
                            //                Section(header: Text("Picture", comment: "Section Header - Picture")) {
                            if image != nil {
                                image!
                                    .resizable()
                                    .scaledToFit()
                                    .cornerRadius(12)
                                    .onTapGesture { self.showImagePicker.toggle() }
                            } else {
                                Button(action: { self.showImagePicker.toggle() }) {
                                    Text("Select Image", comment: "Select Image Button")
                                        .accessibility(identifier: "Select Image")
                                }
                            }
                            //                }
                            
                            // Section Save / Reset
                            //                        VStack {
                            //                            Button() {
                            //                                saveImage()
                            //                            } label: {
                            //                                Text("Save")
                            //                            }
                            //
                            //                        }
                        }
                        .sheet(isPresented: $showImagePicker, onDismiss: loadImage) { ImagePicker2(image: self.$inputImage) }                        .padding()
                        
                        // MARK: color circle
                        ZStack(alignment: .topLeading) {
                            VStack(alignment: .center, spacing: 12) {
                                // MARK: sample card colors
                                let colors: [String] =
                                ["Yellow", "Blue", "Purple", "Green", "Red"]
                                HStack(spacing: 15){
                                    ForEach(colors, id: \.self) { color in
                                        ZStack(alignment: .center) {
                                            Circle()
                                                .fill(taskModel.currentColor == color ? Color(color).opacity(0.45) : Color.clear)
                                                .frame(width: 24, height: 24, alignment: .center)
                                                .overlay(
                                                    Circle().stroke(Color(color), lineWidth: 4)
                                                )
                                                .onTapGesture {
                                                    taskModel.currentColor = color
                                                    taskColor = color
                                                }
                                        }
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                        }
                        // Disabling date for edit mode
                        if taskModel.editTask == nil{
                            HStack{
                                GroupBox{
                                    DatePicker("", selection: $taskDate)
                                        .datePickerStyle(.graphical)
                                    //                        .datePickerStyle(.automatic)
                                    //                                .datePickerStyle(.compact)
                                        .labelsHidden()
                                }
                            }
                        }
                        Spacer()
                    }
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
                            keyBoardFocused = true
                        }
                    }
                    .padding()
                    .listStyle(.insetGrouped)
                    .navigationTitle("😶")
                    //            .navigationTitle(taskModel.fetchFeelEmoji())
                    .navigationBarTitleDisplayMode(.inline)
                    // MARK: disbaling dismiss on swipe
                    .interactiveDismissDisabled()
                    // MARK: action btns
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button(){
                                // simple create a new entity object with context and set the values for the object and finally save the context, this will create a new object in our core data
                                if let task = taskModel.editTask{
                                    task.taskTitle = taskTitle
                                    task.taskDescription = taskDescription
                                    task.taskColor = taskColor
                                    // MARK: try save image
                                } else {
                                    let task = Task(context: context)
                                    task.taskTitle = taskTitle
                                    task.taskDescription = taskDescription
                                    task.taskDate = taskDate
                                    task.taskColor = taskColor
                                    task.taskImage = inputImage?.jpegData(compressionQuality: 1.0)
                                }
                                do {
                                    // saving
                                    try context.save()
                                    print("item of memo is saved, how about the taskImage? c")
                                    taskModel.currentColor = ""
                                } catch {
                                    print(error.localizedDescription)
                                }
                                // Dismissing view
                                taskModel.addNewTask.toggle()
                                taskModel.currentColor = ""
                            } label: {
                                Image(systemName: "square.and.arrow.down.fill")
                                    .foregroundColor(.gray)
                                
                            }// taskTitle == "" ||
                            .disabled(taskDescription == "")
                        }
                        
                        ToolbarItem(placement: .navigationBarLeading) {
                            Button(){
                                dismiss()
                                taskModel.currentColor = ""
                                withAnimation {
                                    
                                    taskModel.addNewTask.toggle()
                                }
                            } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    // loading task data if from edit
                    .onAppear {
                        if let task = taskModel.editTask{
                            taskTitle = task.taskTitle ?? ""
                            taskDescription = task.taskDescription ?? ""
                        }
                    }
                }
            }
        }
    }// p

//    func saveImage() {
//
//        let task = Task(context: context)
////            let pickedImage = inputImage?.jpegData(compressionQuality: 1.0)
//        task.taskImage = inputImage?.jpegData(compressionQuality: 1.0)
//
//        do {
//            // saving
//            try context.save()
//            print("image of task is saved")
//        } catch {
//            print(error.localizedDescription)
//        }
//        //  Save to Core Data
//
//    }
    func loadImage() {
        guard let inputImage = inputImage else { return }
        image = Image(uiImage: inputImage)
    }
    
    struct ImagePicker: UIViewControllerRepresentable {
        
        func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
            let picker = UIImagePickerController()
            picker.delegate = context.coordinator
            return picker
        }

        func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {

        }

        // MARK: - Environment Object
        @Environment(\.managedObjectContext) var presentationMode
        @Environment(\.dismiss) var dismiss
        @Binding var image: UIImage?

        // MARK: - Coordinator Class
        class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
            let parent: ImagePicker

            init(_ parent: ImagePicker) {
                self.parent = parent
            }

            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
                if let uiImage = info[.originalImage] as? UIImage {
                    parent.image = uiImage
                }
                parent.dismiss()
            }
        }

        func makeCoordinator() -> Coordinator {
            Coordinator(self)
        }


    }
}

// https://www.hackingwithswift.com/quick-start/swiftui/how-to-convert-a-swiftui-view-to-an-image

extension View {
    func snapshot() -> UIImage {
        let controller = UIHostingController(rootView: self)
        let view = controller.view

        let targetSize = controller.view.intrinsicContentSize
        view?.bounds = CGRect(origin: .zero, size: targetSize)
        view?.backgroundColor = .orange

        let renderer = UIGraphicsImageRenderer(size: targetSize)

        return renderer.image { _ in
            view?.drawHierarchy(in: controller.view.bounds, afterScreenUpdates: true)
            print("Image saved.")
        }
    }
}


