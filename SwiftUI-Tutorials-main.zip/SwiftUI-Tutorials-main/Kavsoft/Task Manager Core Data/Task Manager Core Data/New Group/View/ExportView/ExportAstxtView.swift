//
//  ExportAstxtView.swift
//  Task Manager Core Data
//
//  Created by 陈安冉 on 2023/1/19.
//

import SwiftUI
import CoreData

struct ExportAstxtView: View {

    @StateObject private var taskModel: TaskViewModel = TaskViewModel()
    @FetchRequest(sortDescriptors: [SortDescriptor(\.taskDate)])
    private var task4Export: FetchedResults<Task>
    var body: some View {
        VStack{
            Spacer()
            Button(action: {
                saveString()
            }, label: {
                Image(systemName: "star.fill")
            })
            List(task4Export) { sth in
                VStack(alignment: .leading) {
                    Text(sth.taskDate?.formatted(date: .complete, time: .standard) ?? "Time Not Specialized.")
                        .foregroundColor(.blue)
                    Text(sth.taskDescription ?? "Unknown")
                        .foregroundColor(.red)
                }
            }
        }
    }
    
    func appendString() -> String {
        var string2Export: String = ""
        // ForEach with capital F belongs to the rendering area of a SwiftUI View. A class is the wrong place.
            for sth in task4Export {
                string2Export.append(sth.taskDate?.formatted(date: .complete, time: .complete) ?? "Time Not Specialized.")
                string2Export.append(" ")
                string2Export.append(sth.taskColor ?? "Un")
//                string2Export.joined(separator: "\n")
                string2Export.append("\n")
                string2Export.append(sth.taskDescription ?? "Un")
                string2Export.append("\n")
                string2Export.append("\n")
            }
        return string2Export
        }
    
    // MARK: try save to txt
    func saveString() {
        let str = appendString()
        let filename = getDocumentsDirectory().appendingPathComponent("output.txt")
        print("Saved.")
        do {
            try str.write(to: filename, atomically: true, encoding: String.Encoding.utf8)
        } catch {
            // failed to write file – bad permissions, bad filename, missing permissions, or more likely it can't be converted to the encoding
            print(error.localizedDescription)
        }
        
        func getDocumentsDirectory() -> URL {
            let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            print(paths[0])
            return paths[0]
        }
    }
}

struct ExportAstxtView_Previews: PreviewProvider {
    static var previews: some View {
        ExportAstxtView()
    }
}








//struct DynamicFilteredExportView<Content: View, S>: View
//where S: NSManagedObject {
//    // core data request
//    @FetchRequest var request: FetchedResults<S>
//    let content: (S) -> Content
//
//    var body: some View {
//        ForEach(request, id: \.objectID){ object in
//            self.content(object)
//        }
//    }
//}
