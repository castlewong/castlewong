////
////  TryCharts.swift
////  Task Manager Core Data
////
////  Created by KIOXIA on 2022/12/21.
////
//
//import SwiftUI
//import Charts
//import CoreData
//
//struct Pancakes: Identifiable {
//    let name: String
//    let sales: Int
//    
//    var id: String { name }
//}
//
//
//let sales: [Pancakes] = [
//    .init(name: "Cachapa", sales: 916),
//    .init(name: "Inj", sales: 850),
//    .init(name: "Indj", sales: 550),
//    .init(name: "Pancakes", sales: 990),
//    .init(name: "InHAmerican", sales: 550)
//]
//
//
//struct TryCharts: View {
//    
//    @Environment(\.managedObjectContext) private var viewContext
//    
////    @Environment(\.managedObjectContext) var context
//    @FetchRequest(
//        entity: Task.entity(),
//        sortDescriptors: [
//            NSSortDescriptor(keyPath: \Task.taskDate, ascending: true)
//        ])
//    private var task: FetchedResults<Task>
//    
//    // try charts
//    class TaskItem: ObservableObject, Identifiable{
//        var id = UUID()
//        @Published var test1: String = ""
//        @Published var test2: String = ""
//        
//        
//        init(test1: String, test2: String) {
//            self.test1 = test1
//            self.test2 = test2
//        }
//    }
//
//    
//    var body: some View {
//        VStack{
//
//            GroupBox ("Test") {
//                Chart(sales) { element in
//                    BarMark(
//                        x: .value("Sales", element.sales),
//                        y: .value("Name", element.name)
//                    )
//                }
//                .foregroundColor(Color.orange)
//            }
//            Spacer()
//        }
//        .padding()
//        .frame(height: 400)
//    }
//}
//
//struct TryCharts_Previews: PreviewProvider {
//    static var previews: some View {
//        TryCharts()
//    }
//}
