//
//  CustomWeekHeader.swift
//  Task Manager Core Data
//
//  Created by 陈安冉 on 2023/1/15.
//

import SwiftUI

struct CustomWeekHeader: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CustomWeekHeader_Previews: PreviewProvider {
    static var previews: some View {
        CustomWeekHeader()
    }
}
