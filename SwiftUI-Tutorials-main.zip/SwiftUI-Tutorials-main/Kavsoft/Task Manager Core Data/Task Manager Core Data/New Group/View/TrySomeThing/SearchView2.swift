////
////  SearchView2.swift
////  Task Manager Core Data
////
////  Created by KIOXIA on 2022/12/11.
////
//
//import SwiftUI
//
//struct SearchView2: View {
//
//    @Environment(\.managedObjectContext) var context
//    @FetchRequest(entity: Task.entity(), sortDescriptors: [])
//    private var results: FetchedResults<Task>
//
//    @State private var query = ""
//
//    var body: some View {
//        NavigationView{
//            List(results) { result in
//                Text(result.taskTitle!)
//            }
//        }
//        .searchable(text: $query, prompt: "Search Content")
//        .onChange(of: query) { newValue in
//            results.nsPredicate = searchPredicate(query: newValue)
//        }
//    }
//
//    private func searchPredicate(query: String) -> NSPredicate? {
//        if query.isEmpty { return nil }
//        return NSPredicate(format: "%K BEGINSWITH[cd] %@", #keyPath(Task.taskTitle), query)
//    }
//
//}
//
//struct SearchView2_Previews: PreviewProvider {
//    static var previews: some View {
//        SearchView2()
//    }
//}
