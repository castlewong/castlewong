////
////  SearchView.swift
////  Task Manager Core Data
////
////  Created by KIOXIA on 2022/12/11.
////
//
import SwiftUI

struct SearchView: View {
    
    // MARK: try search 2022-12-15 23:19:40
    @State var searchText = ""
    @Environment(\.dismiss) var dismiss

    
    @StateObject var taskModel: TaskViewModel = TaskViewModel()
    
    // MARK: Core Data Context
    @Environment(\.managedObjectContext) var context
    
    // MARK: Edit btn context
    @Environment(\.editMode) var editButton
    
    var body: some View {
        NavigationView{
            ScrollView{
                HStack{
                    Button(){
                        dismiss()
                    } label: {
                        Image(systemName: "return")
                    }
//                    EditButton()
                    
                }
                TasksView()
//                DynamicFilteredForSearchView(dataToFilter: searchText) { (object: Task) in
//                    TaskCardView(task: object)
//                }
                
            }
//            .toolbar{
//                ToolbarItem(placement: .navigationBarTrailing) {
//                    Button() {
//                        dismiss()
//                    } label: {
//                        Image(systemName: "return")
//                            .foregroundColor(.black)
//                    }
//
//                }
//
//                ToolbarItem(placement: .navigationBarLeading) {
//                    Text("🔖")
//                }
//            }

        }
        .searchable(text: $searchText)
    }
    
    // MARK: Tasks view
    func TasksView() -> some View{
        
        
        LazyVStack(spacing: 25){
            
            // Converting object as our task model
            DynamicFilteredForSearchView(dataToFilter: searchText) { (object: Task) in
                
                TaskCardView(task: object)
            }
//            .padding()
        }
//        .padding()
    }
    
    func TaskCardView(task: Task) -> some View{
        
        // MARK: since coredata values will give optinal data
        HStack(alignment: editButton?.wrappedValue == .active ? .center : .top, spacing: 30){
            
            // IF edit mode enabled then showing delete btn edit and delete btn
            if editButton?.wrappedValue == .active{
                
                // Edit button for current and future tasks
                VStack(spacing: 10){
                    
                    if task.taskDate?.compare(Date()) == .orderedDescending || Calendar.current.isDateInToday(task.taskDate ?? Date()) {
                        Button {
                            taskModel.editTask = task
                            taskModel.addNewTask.toggle()
                            
                        } label: {
                            Image(systemName: "pencil.circle.fill")
                                .font(.title2)
                                .foregroundColor(.primary.opacity(0.7))
                        }
                    }
                        
                        
                    Button {
                        // MARK: Deleting task
                        context.delete(task)
                        
                        // saving
                        try? context.save()
                    } label: {
                        Image(systemName: "minus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.red)
                    }
                }
            } else {
                
            }
             
            VStack{
                
                // MARK: task title and description
                HStack(alignment: .top, spacing: 10) {
                    
                    VStack(alignment: .leading, spacing: 10) {
//
                        Text(task.taskTitle ?? "")
                            .font(.title2.bold())
                            .foregroundColor(.black.opacity(0.8))

                        
                        Text(task.taskDescription ?? "")
                            .font(.body)
                            .foregroundColor(.black.opacity(0.73))
                    }// MARK: time 14:36
                    .hLeading()
                    
                    Text(task.taskDate?.formatted(date: .omitted, time: .shortened) ?? "")
                        .foregroundColor(.black.opacity(0.4))
                }
                
                if taskModel.isCurrentHour(date: task.taskDate ?? Date()){

                }
            }
            .foregroundColor(taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? .white : .black)
            .padding(taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? 12 : 10)
            .padding(.bottom, taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? 5 : 10)
            .hLeading()
            .background(
                Color(task.taskColor ?? "")
                    .cornerRadius(12)
                    .opacity(0.73)
//                    .opacity(taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? 0.8 : 0)
            )
            .shadow(color: Color(task.taskColor ?? "").opacity(0.7), radius: 10, x: -12, y: 10)
            .onTapGesture(perform: {
                taskModel.editTask = task
                taskModel.addNewTask.toggle()
            })
        }
        .padding(.horizontal)

        //        .hLeading()
    }

}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
