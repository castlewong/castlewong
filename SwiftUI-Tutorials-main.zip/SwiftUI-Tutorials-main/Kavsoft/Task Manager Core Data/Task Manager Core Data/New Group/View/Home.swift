//
//  Home.swift
//  Task Manager Prepare
//
//  Created by KIOXIA on 2022/11/27.
//

import SwiftUI
import UIKit

struct Home: View {
    
    @FetchRequest(sortDescriptors: [
        SortDescriptor(\.taskDate)])
    var tasks: FetchedResults<Task>

    
    @State private var showingSearchView = false
    @State private var showingImageView = false
    @State private var showingHeaderView = false

    @StateObject var taskModel: TaskViewModel = TaskViewModel()
    
    @Namespace var animation
    
    // MARK: Core Data Context
    @Environment(\.managedObjectContext) var context
    
    // MARK: Edit btn context
    @Environment(\.editMode) var editButton
    
    @State var isEditing = false
    
    let startDate: Date = Calendar.current.date(from: DateComponents(year: 2021)) ?? Date()
    let endDate: Date = Date()
    
    var body: some View {
        
        if taskModel.addNewTask {
            NewTask().environmentObject(taskModel)
//                .animation(Animation.spring().speed(2.5))
                .transition(.move(edge: .top))

        } else {
            
            ScrollView(.vertical, showsIndicators: false){
                
                // MARK: lazy stack with pinned header
                LazyVStack(spacing: 4, pinnedViews: [.sectionFooters]) {
                    
                    Section {
                        
                        // MARK: top header of tools
                        HStack{
                                                        
                            Button(action: {
                                showingSearchView.toggle()
                            }, label: {
                                Text("🔍")
                            })
                            .sheet(isPresented: $showingSearchView) {
                                // clearing edit data
                                
                            } content: {
                                SearchView()
                            }
                            Button(action: {
                                withAnimation(.linear(duration: 0.1)){
                                    self.isEditing.toggle()
                                }
                            }) {
                                Text(isEditing ? "👌" : "🖊️")
//                                    .frame(width: 40)
                            }
                            .environment(\.editMode, .constant(self.isEditing ? EditMode.active : EditMode.inactive)
                            )
                            Button(action: {
                                showingHeaderView.toggle()
//                                taskModel.saveAsTxt()
                            }, label: {
                                Text("🌘")
                                    .font(.largeTitle)
                                
                            })
                            .sheet(isPresented: $showingHeaderView) {
                                // clearing edit data
                            } content: {
                                countColor(dataOfPercent: [Double(tasks.count), Double(tasks.count)])
//                                CustomWeekHeader2()
//                                ExportAstxtView()
//                                PieChart()
                            }
                            
                            DatePicker("", selection: $taskModel.currentDay, in: startDate...endDate, displayedComponents: [.date])
                                .accentColor(Color.black)
                                .datePickerStyle(
                                    CompactDatePickerStyle()
                                )
                        }
                        .padding(.horizontal)
//                        .padding(.trailing, 14)
                        
                        
                        // MARK: current week view
                        
                            HStack(spacing: 12){
                                ForEach(taskModel.currentWeek, id: \.self) { day in
                                    
                                    VStack(spacing: 10) {
                                        // day
                                        Text(taskModel.extractDate(date: day, format: "dd"))
                                            .font(.system(size: 15))
                                            .fontWeight(.semibold)
                                        
                                        // EEE will return day as MON, TUE, ...
                                        // weekday
                                        Text(taskModel.extractDate(date: day, format: "EEE"))
                                            .font(.system(size: 14))
                                    }
                                    .foregroundStyle(taskModel.isToday(date: day) ? .primary : .tertiary)
                                    .foregroundColor(taskModel.isToday(date: day) ? .white : .black)
                                    
                                    // MARK: capsule shape
                                    .frame(width: 45, height: 80)
                                    .background(
                                        ZStack {
                                            // MARK: Matched geometry effect
                                            if taskModel.isToday(date: day){
                                                Capsule()
                                                    .fill(.gray.opacity(0.5))
                                                    .matchedGeometryEffect(id: "CURRENTDAY", in: animation)
                                            }
                                        }
                                    )
                                    .contentShape(Capsule())
                                    .onTapGesture {
                                        // updating current day
                                        withAnimation{
                                            taskModel.currentDay = day
                                        }
                                    }
                                }
                            }
                            .padding(.horizontal)
                        
                        
                        //                    SearchBar(text: $searchText)
                        //                        .padding(.top, -20)
                        TasksView()
                        
                    }
                header: {
                        HeaderView()
                    }
                    
                }
                
                
            }
            
//            .animation(nil)
            .transition(.move(edge: .top))
            //    }.searchable(text: $searchText)
            .ignoresSafeArea(.container, edges: .top)
            // MARK: add btn eg magicwheel
            .overlay(
                    Button(action: {
                        withAnimation(.spring(response: 0.2, dampingFraction: 1)) {
                            taskModel.addNewTask.toggle()
                        }
                    }, label: {
                        
                                Circle() // magic wheel
                                    .strokeBorder(
                                        
                                        AngularGradient(gradient: Gradient(colors: [.red, .orange, .yellow, .yellow, .green, .green, .blue, .blue, .purple, .purple, .red]), center: .center, startAngle: .degrees(360)), lineWidth: 4.2
                                        
                                    )
                                    .background(Circle().fill(.white .opacity(0.7)))
                                    .shadow(color: .gray.opacity(0.3), radius: 5, x: -3, y: 3)
                                    .frame(width: 65, height: 65)
                            
                    })
                
//                Button("Togg") {
//                    withAnimation(.easeInOut) {
//                        taskModel.addNewTask.toggle()
//                    }
//                }
//                .onTapGesture {
//                    withAnimation {
//                        taskModel.addNewTask.toggle()
//                        print("ss")
//                    }
//                }
                .padding(), alignment: .bottom
            )
            //        .sheet(isPresented: $taskModel.addNewTask) {
            //            // clearing edit data
            //            // Publishing changes from within view updates is not allowed, this will cause undefined behavior.
            //            taskModel.editTask = nil
            //        } content: {
            //            NewTask()
            //                .environmentObject(taskModel)
            //        }
        }
    }
    // MARK: Tasks view
    func TasksView() -> some View{
        
        LazyVStack(spacing: 25){
            
            // Converting object as our task model
            DynamicFilteredView(dateToFilter: taskModel.currentDay) { (object: Task) in
                TaskCardView(task: object)
            }

        }
        .padding()
        

    }

    // MARK: Task card view
    func TaskCardView(task: Task) -> some View{
        
        // MARK: since coredata values will give optinal data
        HStack(alignment: self.isEditing == true ? .center : .top, spacing: 10){
            
            // IF edit mode enabled then showing delete btn edit and delete btn
            if self.isEditing == true{
                
                // Edit button for current and future tasks
                HStack(spacing: 10){
                    
//                    if task.taskDate?.compare(Date()) == .orderedDescending || Calendar.current.isDateInToday(task.taskDate ?? Date()) {
//
                    Button {
                            taskModel.editTask = task
                            taskModel.addNewTask.toggle()
                        } label: {
                            Image(systemName: "pencil.circle.fill")
                                .font(.title2)
                                .foregroundColor(.primary.opacity(0.7))
                        }
//                    }
                        
                        
                    Button {
                        // MARK: Deleting task
                        context.delete(task)
                        
                        // saving
                        try? context.save()
                    } label: {
                        Image(systemName: "minus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.red)
                    }
                }
            } else {

            }
            VStack{
                // MARK: task title and description
                HStack(alignment: .top, spacing: 10) {
                    VStack(alignment: .leading, spacing: 10) {
//                        Text(task.taskTitle ?? "")
//                            .font(.title2.bold())
//                            .foregroundColor(.black.opacity(0.8))
                        
                        Text(task.taskDescription ?? "")
                            .font(.body)
                            .foregroundColor(.black.opacity(0.9))

                    }// MARK: time 14:36
                    .hLeading()
                    
                    Text(task.taskDate?.formatted(date: .omitted, time: .shortened) ?? "")
                        .foregroundColor(.black.opacity(0.5))
                }
                
                if task.taskImage != nil {
                                    Image(uiImage: UIImage(data: task.taskImage ?? Data()) ?? UIImage())
                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(8)
                    
                } else {
                    
                }
                
                if taskModel.isCurrentHour(date: task.taskDate ?? Date()){
                }
            }
            .foregroundColor(taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? .white : .black)
            .padding(taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? 12 : 10)
            .padding(.bottom, taskModel.isCurrentHour(date: task.taskDate ?? Date()) ? 0 : 0)
            .hLeading()
            .background(
                Color(task.taskColor ?? "")
                    .cornerRadius(12)
                    .opacity(0.73)
            )
            .shadow(color: Color(task.taskColor ?? "").opacity(0.7), radius: 10, x: -12, y: 10)
            .onTapGesture(perform: {
                taskModel.editTask = task
                taskModel.addNewTask.toggle()
            })
            
        }
        .hLeading()
    }
    
    // MARK: header
    func HeaderView()->some View{
        
        HStack(spacing: 0){
//
//            VStack(alignment: .leading, spacing: 10) {
//
//                Text(Date().formatted(date: .abbreviated, time: .omitted))
//                    .foregroundColor(.gray)
//
//            }
//            .hLeading()
            
            // MARK: edit btn
//            EditButton()
            
        }
//        .padding()
        .padding(.top, getSafeArea().top)
        .background(Color.white)
    }
    
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
//            .environment(\.locale, .init(identifier: "en"))
    }
}

// MARK: UI design helper functions
extension View{
    
    func hLeading()->some View{
        self
            .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    func hTrailing()->some View{
        self
            .frame(maxWidth: .infinity, alignment: .trailing)
    }
    
    func hCenter()->some View{
        self
            .frame(maxWidth: .infinity, alignment: .center)
    }
    
    // MARK: safe area
    func getSafeArea() -> UIEdgeInsets {
        guard let screen = UIApplication.shared.connectedScenes.first as? UIWindowScene else{
            return .zero
        }
        
        guard let safeArea = screen.windows.first?.safeAreaInsets else{
            return .zero
        }
        
        return safeArea
    }
    
// MARK: try save as image func at extension
    func saveAndShare(img:UIImage) {
        let fileManager = FileManager.default
        let rootPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first! as NSString
        let filePath = "\(rootPath)/share.jpg"
        let imageData = img.jpegData(compressionQuality: 1.0)
        fileManager.createFile(atPath: filePath, contents: imageData, attributes: nil)
        let url:URL = URL.init(fileURLWithPath: filePath)
        let av = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        UIApplication.shared.windows.first?.rootViewController!.present(av, animated: true, completion: nil)
        // https://blog.csdn.net/qq_15041159/article/details/120974427 and https://zenn.dev/paraches/articles/windows_was_depricated_in_ios15
    }
    
    
}



