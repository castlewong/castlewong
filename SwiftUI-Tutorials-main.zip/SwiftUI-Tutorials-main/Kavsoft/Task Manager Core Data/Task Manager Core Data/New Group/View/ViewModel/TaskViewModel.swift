//
//  TaskViewModel.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/1.
//

import SwiftUI
import CoreData

class TaskViewModel: ObservableObject{
    
    // MARK: try searchText
    @Published var searchText: String = ""
    @Published var isSearching: Bool = false
//    @Published var taskModels =
    
    // MARK: try color
    @Published var currentColor: String = ""
    
    // MARK: try emoji
    @Published var currentEmoji: String = ""
    
    // MARK: current week days
    @Published var currentWeek: [Date] = []
    
    // MARK: current day
    @Published var currentDay: Date = Date()
    
    // MARK: try current months
    @Published var currentMonth: [Date] = []
    
    // MARK: filtering today tasks
    @Published var filteredTasks: [Task]?
    
    // MARK: new task view
    @Published var addNewTask: Bool = false
    // try 2023-01-13 23:01:44
    @Published var showSAIview: Bool = false
    
    // MARK: edit data
    @Published var editTask: Task?
    
    // MARK: Intializing
    init(){
        fetchCurrentWeek()
    }

    // MARK: try title
//    func fetchFeelEmoji(){
//        
//        var theKindEmoji = "😶"
//        
//        if currentColor == "Blue"{
//            theKindEmoji = "😨"
//        } else if currentColor == "Red"{
//            theKindEmoji = "😡"
//        } else{
//            
//        }
//        
//    }
    

    
    func fetchCurrentWeek(){
        
        let today = Date()
        var calendar = Calendar.current
        calendar.firstWeekday = 1
        let week = calendar.dateInterval(of: .weekOfMonth, for: today)
        
        guard let firstWeekDay = week?.start else{
            return
        }
        
        (1...7).forEach { day in
            if let weekday = calendar.date(byAdding: .day, value: day, to: firstWeekDay){
                currentWeek.append(weekday)
            }
        }
    }
    
    // MARK: Extracting date
    func extractDate(date: Date, format: String) -> String{
        let formatter = DateFormatter()
        
        formatter.dateFormat = format
        
        return formatter.string(from: date)
    }
    
    // MARK: checking if current date is today
    func isToday(date: Date) -> Bool {
        let calendar = Calendar.current
        return calendar.isDate(currentDay, inSameDayAs: date)
    }
    
    // MARK: Checking if the currentHour is task Hour
    func isCurrentHour(date: Date) -> Bool {
        
        let calendar = Calendar.current
        
        let hour = calendar.component(.hour, from: date)
        let currentHour = calendar.component(.hour, from: Date())
        
        let isToday = calendar.isDateInToday(date)
        
        return (hour == currentHour && isToday)
    }
}
