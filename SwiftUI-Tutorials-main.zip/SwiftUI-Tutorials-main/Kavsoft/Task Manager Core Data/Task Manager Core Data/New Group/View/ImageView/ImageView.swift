//
//  ImageView.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/23.
//  https://youtu.be/f5YhkfPyXmw 34.32 done
//
//import SwiftUI
//import CoreData
//
//struct ImageView: View {
//    @Environment(\.managedObjectContext) private var viewContext
//    @FetchRequest(
//        entity: Task.entity(),
//        sortDescriptors: [
//            NSSortDescriptor(keyPath: \Task.taskTitle, ascending: true),
//            NSSortDescriptor(keyPath: \Task.taskImage, ascending: true)
//        ])
//    private var task: FetchedResults<Task>
//
//    @State private var image: Data = .init(count: 0)
//    @State private var show: Bool = false
//    var body: some View {
//        NavigationView {
//            ScrollView(.vertical, showsIndicators: false) {
//                ForEach(task, id: \.taskTitle) { element in
//                    VStack {
//                        Image(uiImage: UIImage(data: element.taskImage ?? self.image)!)
//                            .resizable()
//
//                        Text(element.taskTitle!)
//                    }
//                }
//
//            }.navigationTitle("Coredata")
//            .toolbar {
//                ToolbarItem(placement: .navigationBarTrailing) {
//                    Button(action: {
//                        self.show.toggle()
//                    }) {
//                        Image(systemName: "plus")
//                    }
//                }
//            }
//
//            .sheet(isPresented: self.$show) {
//                AddInfo().environment(\.managedObjectContext, self.viewContext)
//            }
//
//        }
//    }
//}
//
//
//struct AddInfo: View {
//    @Environment(\.managedObjectContext) private var moc
//    @Environment(\.dismiss) private var dismiss
//
//    @State private var name: String = ""
//    @State private var image: Data = .init(count: 0)
//    @State private var show: Bool = false
//
//    var body: some View {
//        VStack {
//            if self.image.count != 0 {
//                Button(action: {
//                    self.show.toggle()
//                }) {
//                    Image(uiImage: UIImage(data: self.image)!)
//                        .renderingMode(.original)
//                        .resizable()
//                        .frame(width: 150, height: 150)
//                        .cornerRadius(20)
//                }
//            } else {
//                    Button(action: {
//                        self.show.toggle()
//                    }) {
//                        Image(systemName: "photo.fill")
//                            .resizable()
//                            .frame(width: 150, height: 150)
//                            .cornerRadius(20)
//                            .shadow(radius: 8)
//                            .foregroundColor(.black)
//                    }
//                }
//                TextField("Name", text: self.$name)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                Button(action: {
//                    let save = Task(context: self.moc)
//                    save.taskImage = self.image
//                    save.taskTitle = self.name
//
//
//                    try! self.moc.save()
//
//                    self.name = ""
//
//                    dismiss()
//                }) {
//                    Text("Save Info")
//                }
//            }
//        .sheet(isPresented: self.$show) {
//            // ImagePicker
//            ImagePicker(images: self.$image, show: self.$show)
//        }
//    }
//}
//
//struct ImagePicker: UIViewControllerRepresentable {
//
//    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
//
//    }
//
//    @Binding var images: Data
//    @Binding var show: Bool
//
//    func makeCoordinator() -> Coordinator {
//        return ImagePicker.Coordinator(img1: self)
//    }
//
//    func makeUIViewController(context: Context) -> UIImagePickerController {
//
//        let picker = UIImagePickerController()
//        picker.sourceType = .photoLibrary
//        picker.delegate = context.coordinator
//
//        return picker
//    }
//
//
//
//    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//        var img0: ImagePicker
//
//        init(img1: ImagePicker) {
//            img0 = img1
//        }
//
//        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//            self.img0.show.toggle()
//
//        }
//
//        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//
//            let image = info[.originalImage] as? UIImage
//
//            let data = image?.jpegData(compressionQuality: 0.50)
//
//            self.img0.images = data!
//            self.img0.show.toggle()
//        }
//    }
//}
//
//
//struct ImageView_Previews: PreviewProvider {
//    static var previews: some View {
//        ImageView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
//    }
//}
