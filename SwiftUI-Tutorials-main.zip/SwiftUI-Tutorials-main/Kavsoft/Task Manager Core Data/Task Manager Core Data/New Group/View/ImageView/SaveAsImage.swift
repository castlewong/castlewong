//
//  SaveAsImage.swift
//  Task Manager Core Data
//
//  Created by 陈安冉 on 2023/1/12.
//
import SwiftUI

extension UIView {
    func asImage(rect: CGRect) -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: rect)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
}

struct SaveAsImage: View {
    @State  var rect1: CGRect = .zero
    @State  var rect2: CGRect = .zero
    @State  var uiimage: UIImage? = nil
    @State  var textDes: String
    @State  var textDate: Date
    var body: some View {
        VStack {
            HStack {
                    Text(textDes)
//                    Text(textDate.formatted(date: .omitted, time: .shortened))
                }
                .padding(20)
                .background(Color.green.blur(radius: 20))
                .border(Color.green, width: 6)
                .background(RectGetter(rect: $rect1))
                .onTapGesture {
                    let keyWindow = UIApplication.shared.connectedScenes

                        .filter({$0.activationState == .foregroundActive})

                        .map({$0 as? UIWindowScene})

                        .compactMap({$0})

                        .first?.windows

                        .filter({$0.isKeyWindow}).first
                    
                    self.uiimage = keyWindow?.rootViewController?.view.asImage(rect: self.rect1)
                    if(uiimage != nil){
                        saveAndShare(img: uiimage!)
                    }
                }

                VStack {
                    Text("RIGHT")
                    Text("VIEW")
                }
                .padding(40)
                .background(Color.yellow)
                .border(Color.green, width: 5)
                .background(RectGetter(rect: $rect2))
                .onTapGesture {
                    let keyWindow = UIApplication.shared.connectedScenes

                        .filter({$0.activationState == .foregroundActive})

                        .map({$0 as? UIWindowScene})

                        .compactMap({$0})

                        .first?.windows

                        .filter({$0.isKeyWindow}).first
                    
                    self.uiimage = keyWindow?.rootViewController?.view.asImage(rect: self.rect2)
                                        if(uiimage != nil){
                        saveAndShare(img: uiimage!)
                    }
                }

            }
            if uiimage != nil {
                VStack {
                    Text("Captured Image")
                    Image(uiImage: self.uiimage!).padding(20).border(Color.black)
                }.padding(20)
            }

        }    
}

struct RectGetter: View {
    @Binding var rect: CGRect

    var body: some View {
        GeometryReader { proxy in
            self.createView(proxy: proxy)
        }
    }

    func createView(proxy: GeometryProxy) -> some View {
        DispatchQueue.main.async {
            self.rect = proxy.frame(in: .global)
        }

        return Rectangle().fill(Color.clear)
    }
}



//struct SaveAsImage_Previews: PreviewProvider {
//    static var previews: some View {
//        SaveAsImage()
//    }
//}
