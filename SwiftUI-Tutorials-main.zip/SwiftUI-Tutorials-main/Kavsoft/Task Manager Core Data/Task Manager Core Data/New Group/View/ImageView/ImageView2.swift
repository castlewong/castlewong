//
//  ImageView2.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/25.
//https://www.hackingwithswift.com/forums/swiftui/saving-images-with-core-data-in-swiftui/1241

import SwiftUI

struct ImagePicker2: UIViewControllerRepresentable {
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker2>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker2>) {

    }

    // MARK: - Environment Object
    @Environment(\.managedObjectContext) var presentationMode
    @Environment(\.dismiss) var dismiss
    @Binding var image: UIImage?

    // MARK: - Coordinator Class
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker2

        init(_ parent: ImagePicker2) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage
            }
            parent.dismiss()
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }


}

//My SwiftUI Form where i select the image and save it in CoreData
struct ImageToCoreData2: View {
    
    // Image
    @State private var image: Image?
    @State private var showImagePicker = false
    @State private var inputImage: UIImage?
    @Environment(\.managedObjectContext) var context

    func save() {
        let pickedImage = inputImage?.jpegData(compressionQuality: 1.0)
        do {
            // saving
            try context.save()
            print("item of memo is saved")
        } catch {
            print(error.localizedDescription)
        }
        //  Save to Core Data
    }
    
    func loadImage() {
        guard let inputImage = inputImage else { return }
        image = Image(uiImage: inputImage)
    }
    
    // MARK: - Body
    var body: some View {
        
        // MARK: - Return View
        return NavigationView {
            Form {
                // Section Picture
                Section(header: Text("Picture", comment: "Section Header - Picture")) {
                    if image != nil {
                        image!
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(12)
                            .onTapGesture { self.showImagePicker.toggle() }
                    } else {
                        Button(action: { self.showImagePicker.toggle() }) {
                            Text("Select Image", comment: "Select Image Button")
                                .accessibility(identifier: "Select Image")
                        }
                    }
                }
                
                // Section Save / Reset
                Section {
                    Button(action: save) {
                        Text("Save", comment: "Save Button")
                    }
                }
            }
            .sheet(isPresented: $showImagePicker, onDismiss: loadImage) { ImagePicker2(image: self.$inputImage) }
        }
    }
}


struct ImageToCoreData_Previews: PreviewProvider {
    static var previews: some View {
        ImageToCoreData2()
    }
}
