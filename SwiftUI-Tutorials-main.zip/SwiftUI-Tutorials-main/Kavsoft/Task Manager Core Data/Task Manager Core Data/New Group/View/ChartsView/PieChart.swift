//
//  PieChart.swift
//  Task Manager Core Data
//
//  Created by 陈安冉 on 2023/1/19.
//

import SwiftUI

// MARK: try count entities

//struct countColor_Preview: PreviewProvider {
//    
//    static var previews: some View {
////        countColor()
//    }
//}

struct countColor: View {
    @FetchRequest(sortDescriptors: [
        SortDescriptor(\.taskDate)], predicate: NSPredicate(format: "taskColor == %@", "Red")
    ) var tasksRed: FetchedResults<Task>
    
    @FetchRequest(sortDescriptors: [
        SortDescriptor(\.taskDate)], predicate: NSPredicate(format: "taskColor == %@", "Yellow")
    ) var tasksYellow: FetchedResults<Task>
    
    @FetchRequest(sortDescriptors: [
        SortDescriptor(\.taskDate)], predicate: NSPredicate(format: "taskColor == %@", "Blue")
    ) var tasksBlue: FetchedResults<Task>
    
    @FetchRequest(sortDescriptors: [
        SortDescriptor(\.taskDate)])
    var tasks: FetchedResults<Task>
    
    @State var dataOfPercent: [Double] = []
    
    @State var labelsOfPercent: [String] = ["Red", "Blue", "Yellow"]
    @State var colorsOfPercent: [Color] = [.red, .blue, .yellow]
    @State var borderColorOfPercent: Color = .mint
    
//    init(dataOfPercent: [Double]) {
//        self.dataOfPercent = dataOfPercent
//    }
    
    var body: some View {
        VStack {
            Spacer()
            HStack{
                Text(String(tasks.count))
                Text(String(tasksRed.count))
                Text(String(tasksYellow.count))
                Text(String(tasksBlue.count))
            }
            Button(action: {
                dataOfPercent.append(Double(tasksRed.count))
//                colorsOfPercent.append(.yellow)
//                dataOfPercent.append(Double(tasks3.count))
//                colorsOfPercent.append(.green)
            }, label: {
                Image(systemName: "star.fill")
            })
            PieChart(data: $dataOfPercent, labels: $labelsOfPercent, colors: colorsOfPercent, borderColor: borderColorOfPercent)
        }
    }
    // try append func
//    func totalNumOfColor() -> [Double] {
//
//        dataOfPercent.append(Double(tasks1.count))
//        dataOfPercent.append(Double(tasks3.count))
//        return dataOfPercent
//
//    }

}

struct PieChart: View {

    @FetchRequest(sortDescriptors: [
        SortDescriptor(\.taskDate)], predicate: NSPredicate(format: "taskColor == %@", "Red")
    ) var tasksRed: FetchedResults<Task>
    
    
    @Binding var data: [Double]
    @Binding var labels: [String]
//    @State var testdata: [Double] = [1.1, 2.2]
    
    private let colors: [Color]
    private let borderColor: Color
    private let sliceOffset: Double = -.pi / 2
    
    init(data: Binding<[Double]>, labels: Binding<[String]>, colors: [Color], borderColor: Color) {
        //$testdata = data
        self._data = data
        self._labels = labels
        self.colors = colors
        self.borderColor = borderColor
      }
      
      var body: some View {
        GeometryReader { geo in
            
          ZStack(alignment: .center) {
              
            ForEach(0 ..< 2) { index in
                
              PieSlice(startAngle: startAngle(for: index), endAngle: endAngle(for: index))
                    .fill(colors[index % colors.count])
              
              PieSlice(startAngle: startAngle(for: index), endAngle: endAngle(for: index))
                .stroke(borderColor, lineWidth: 12)
              
              PieSliceText(
                title: "\(labels[index])",
                description: String(format: "%.0f million", data[index])
              )
              .offset(textOffset(for: index, in: geo.size))
              .zIndex(1)
            }
          }
          
        }
      }
    
      
      private func startAngle(for index: Int) -> Double {
        switch index {
          case 0:
            return sliceOffset
          default:
            let ratio: Double = data[..<index].reduce(0.0, +) / data.reduce(0.0, +)
            return sliceOffset + 2 * .pi * ratio
        }
      }
      
      private func endAngle(for index: Int) -> Double {
        switch index {
          case data.count - 1:
            return sliceOffset + 2 * .pi
          default:
            let ratio: Double = data[..<(index + 1)].reduce(0.0, +) / data.reduce(0.0, +)
            return sliceOffset + 2 * .pi * ratio
        }
      }
      
      private func textOffset(for index: Int, in size: CGSize) -> CGSize {
        let radius = min(size.width, size.height) / 3
        let dataRatio = (2 * data[..<index].reduce(0, +) + data[index]) / (2 * data.reduce(0, +))
        let angle = CGFloat(sliceOffset + 2 * .pi * dataRatio)
        return CGSize(width: radius * cos(angle), height: radius * sin(angle))
      }
}

struct PieSlice: Shape {
  let startAngle: Double
  let endAngle: Double
  
  func path(in rect: CGRect) -> Path {
    var path = Path()
    let radius = min(rect.width, rect.height) / 2
    let alpha = CGFloat(startAngle)
    
    let center = CGPoint(
      x: rect.midX,
      y: rect.midY
    )
    
    path.move(to: center)
    
    path.addLine(
      to: CGPoint(
        x: center.x + cos(alpha) * radius,
        y: center.y + sin(alpha) * radius
      )
    )
    
    path.addArc(
      center: center,
      radius: radius,
      startAngle: Angle(radians: startAngle),
      endAngle: Angle(radians: endAngle),
      clockwise: false
    )
    
    path.closeSubpath()
    
    return path
  }
}

struct PieSliceText: View {
  let title: String
  let description: String
  
  var body: some View {
    VStack {
      Text(title)
        .font(.headline)
      Text(description)
        .font(.body)
    }
  }
}
//
//struct PieChart_Previews: PreviewProvider {
//    static var previews: some View {
//        PieChart()
//    }
//}
