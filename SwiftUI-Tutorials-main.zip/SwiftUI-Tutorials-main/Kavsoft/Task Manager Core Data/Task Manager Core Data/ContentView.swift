//
//  ContentView.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/11/27.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}
    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
