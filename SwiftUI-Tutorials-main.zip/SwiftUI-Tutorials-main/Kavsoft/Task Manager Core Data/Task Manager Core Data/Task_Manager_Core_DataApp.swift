//
//  Task_Manager_Core_DataApp.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/11/27.
//

import SwiftUI

@main
struct Task_Manager_Core_DataApp: App {
    let persistenceController = PersistenceController.TaskManagermentCoreData

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
