//
//  ShareSheetApp.swift
//  ShareSheet
//
//  Created by 陈安冉 on 2023/1/8.
//  https://youtu.be/WZOvroeUuxI

import SwiftUI

@main
struct ShareSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
