//
//  ContentView.swift
//  ShareSheet
//
//  Created by Castle Wong on 2023/1/8.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home: View {
    
    @State var items: [Any] = []
    @State var sheet = false
    var body: some View {
        
        VStack {
            
            Button(action: {
                
                // adding items to be shared
                
                items.removeAll()
                items.append(UIImage(named: "Pic")!) //Force-unwrap the value to avoid this warning
                sheet.toggle()
                
            }, label: {
                
                Text("Share")
                    .fontWeight(.heavy)
            })
        }
        .sheet(isPresented: $sheet, content: {
            
            ShareSheet(items: items)
        })
    }
}

// MARK: share sheet

struct ShareSheet : UIViewControllerRepresentable {
    
    // the data you need to share ...
    var items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil )
        
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {
         
    }
}
