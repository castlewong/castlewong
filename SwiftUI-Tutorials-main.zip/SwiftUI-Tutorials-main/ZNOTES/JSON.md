
> - 2022-10-18 15:53:50 
> - key value pairs value can be all kinds of sth.
> - JSON object
> - JSON array [ _ ]

