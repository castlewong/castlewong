//
//  searchableApp.swift
//  searchable
//
//  Created by KIOXIA on 2022/12/12.
//

import SwiftUI

@main
struct searchableApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
