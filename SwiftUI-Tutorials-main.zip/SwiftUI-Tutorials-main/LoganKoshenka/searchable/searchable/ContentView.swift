//
//  ContentView.swift
//  searchable
//
//  Created by KIOXIA on 2022/12/12.
//

import SwiftUI

struct ContentView: View {
    
    @State var searchingFor = ""
    let cities = ["Columbus", "Cleveland", "Bellaire"]
    
    var body: some View {
        NavigationView {
            List {
                ForEach(results, id: \.self) { city in
                    NavigationLink(destination: Text(city)) {
                        Text(city)
                    }
                }
            }
            .searchable(text: $searchingFor)
            .navigationTitle("T")
        }
    }
    
    var results: [String] {
        if searchingFor.isEmpty {
            return cities
        } else {
            return cities.filter{ $0.contains(searchingFor) }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
