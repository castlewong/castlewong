//
//  NewToDoView.swift
//  SwiftUICoreData
//
//  Created by 陈安冉 on 2022/10/23.
//

import SwiftUI

struct NewToDoView: View {
    @Environment(\.managedObjectContext) var context

    @State var name: String
    @State var isEditing = false
    @State var priority: Priority
    @Binding var showNewTask: Bool
//    @Binding var todoItems: [ToDoItem]
    
    var body: some View {
        VStack {
            
            Spacer()
            
            VStack {
                TopNavBar(showNewTask: $showNewTask)
                InputNameView(name: $name, isEditing: $isEditing)
                PrioritySelectView(priority: $priority)
                SaveButton(name: $name, showNewTask: $showNewTask, priority: $priority)
            }
            .padding() // all 4 directions
            .background(Color.white)
            .cornerRadius(10, antialiased: true)
            .offset(y: isEditing ? -320 : 0)
            
        }.edgesIgnoringSafeArea(.bottom)
    }
}

// save btn
struct SaveButton: View {
    @Environment(\.managedObjectContext) var context

    @Binding var name: String
    @Binding var showNewTask: Bool
//    @Binding var todoItems: [ToDoItem]
    @Binding var priority: Priority
    
    var body: some View {
        Button(action: {
            if self.name.trimmingCharacters(in: .whitespaces) == "" {
                return
            }
            
            self.addTask(name: self.name, priority: self.priority)
            
            self.showNewTask = false
            
        }) {
            Text("Save")
                .font(.system(.headline))
                .frame(minWidth: 0, maxWidth: .infinity)
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(8)
            
        }
        .padding([.top, .bottom])
    }
    
    private func addTask(name: String, priority: Priority, isCompleted: Bool = false) {
        
        let task = ToDoItem(context: context)
        task.id = UUID()
        task.name = name
        task.priority = priority
        task.isCompleted = isCompleted

        do {
            try context.save()
        } catch {
            print(error)
        }
    }
}

struct InputNameView: View {
    @Binding var name: String
    @Binding var isEditing: Bool
    
    var body: some View {
        TextField("Plz input", text: $name, onEditingChanged: { (editingChanged) in
            
            self.isEditing = editingChanged
        })
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(8)
        .padding(.bottom)
    }}



// choose priority
struct PrioritySelectView: View {
    @Binding var priority: Priority
    
    var body: some View {
        HStack {
            PrioritySelectRow(name: "High", color: priority == .high ? Color.red : Color(.systemGray4))
                .onTapGesture {
                    self.priority = .high
                }
            PrioritySelectRow(name: "Middle", color: priority == .normal ?  Color.orange : Color(.systemGray4))
                .onTapGesture {
                    self.priority = .normal
                }
            PrioritySelectRow(name: "Low", color: priority == .low ? Color.green : Color(.systemGray4))
                .onTapGesture {
                    self.priority = .low
                }
        }
    }
}

// priority row
struct PrioritySelectRow: View {
    var name: String
    var color: Color
    var body: some View {
        Text(name)
            .frame(width: 80)
            .font(.system(.headline))
            .padding(10)
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(8)
    }
}

// top navigation bar
struct TopNavBar: View {
    
    @Binding var showNewTask: Bool
    
    var body: some View {
        
        HStack {
            Text("add todos")
                .font(.system(.title))
                .bold()
            
            Spacer()
            
            Button(action: {
                self.showNewTask = false
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.gray)
                    .font(.title)
            }
        }
    }
}

struct NewToDoView_Previews: PreviewProvider {
    static var previews: some View {
        NewToDoView(name: "",  priority: .normal, showNewTask: .constant(true))
    }
}



