//
//  ContentView.swift
//  SwiftUICoreData
//
//  Created by Castle on 2022/10/22.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    
    @Environment(\.managedObjectContext) var context
    @FetchRequest(
        entity: ToDoItem.entity(),
        sortDescriptors: [ NSSortDescriptor(keyPath: \ToDoItem.priorityNum, ascending: false) ]
    )
    var todoItems: FetchedResults<ToDoItem>
    
    @State private var showNewTask = false
    @State private var offset: CGFloat = .zero // use .animation to prevent bugs for iOS15
    
    
    init() {
        UITableView.appearance().backgroundColor = .clear
        UITableViewCell.appearance().backgroundColor = .clear
    }
    
    var body: some View {
        ZStack {
            VStack {
                TopBarMenu(showNewTask: $showNewTask)
  //            ToDoListRow(todoItems: $todoItems)
                
                List {
                    ForEach(todoItems) { todoItem in
                        ToDoListRow(todoItem: todoItem)
                    }.onDelete(perform: deleteTask)
                }
            }
            
            if todoItems.count == 0 {
                NoDataView()
            }
            
            if showNewTask {
                
                MaskView(bgColor: .black)
                    .opacity(0.5)
                    .onTapGesture {
                        self.showNewTask = false
                    }
                
                NewToDoView(name: "", priority: .normal, showNewTask: $showNewTask)
                    .transition(.move(edge: .bottom))
                    .animation(.interpolatingSpring(stiffness: 200.0, damping: 25.0, initialVelocity: 10.0), value: offset)
            }
        }
    }
    
    
    private func deleteTask(indexSet: IndexSet) {
        for index in indexSet {
            let itemToDelete = todoItems[index]
            
            context.delete(itemToDelete)
        }
        
        DispatchQueue.main.async {
            do {
                try context.save()
                
            } catch {
                print(error)
            }
        }
    }
    
    
    // list
    struct ToDoListView: View {
        // declare a state of todoItems
        @Binding var todoItems: [ToDoItem]
    //    @Binding var showNewTadk: Bool
        
        var body: some
        
        View {
            
            List {
                ForEach(todoItems) { todoItem in
                    ToDoListRow(todoItem: todoItem)
                }
            }
        }
    }

    // row
    struct ToDoListRow: View {
        
        @Environment(\.managedObjectContext) var context
        
//      @Binding var todoItems: [ToDoItem]
        @ObservedObject var todoItem: ToDoItem
        
        var body: some View {
            
            Toggle(isOn: self.$todoItem.isCompleted) {
                HStack {
                    
                    Text(self.todoItem.name)
                        .strikethrough(self.todoItem.isCompleted, color: .black)
                        .bold()
                        .animation(.default)
                    
                    Spacer()
                    
                    Circle()
                        .frame(width: 20, height: 20)
                        .foregroundColor(self.color(for: self.todoItem.priority))
                }
            }
            .toggleStyle(CheckboxStyle())
            
            .onReceive(todoItem.objectWillChange, perform: { _ in
                    if self.context.hasChanges {
                        try? self.context.save()
                    }
                })
            }
        
        // show diff colors by prioity
        private func color(for priority: Priority) -> Color {
            
            switch priority {
            case .high:
                return .red
            case .normal:
                return .orange
            case .low:
                return .green
            }
        }
    }

    
    // checkbox style
    struct CheckboxStyle: ToggleStyle {
        func makeBody(configuration: Self.Configuration) -> some View {
            return HStack {
                
                Image(systemName: configuration.isOn ? "checkmakr.circle.fill" : "circle")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(configuration.isOn ? .purple : .gray)
                    .font(.system(size: 20, weight: .bold, design: .default))
                    .onTapGesture {
                        configuration.isOn.toggle()
                    }
                configuration.label
            }
        }
    }
}


// mask layer
struct MaskView: View {
    var bgColor: Color
    var body: some View {
        VStack {
            Spacer()
        }
        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
        .background(bgColor)
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

// top navigation bar
struct TopBarMenu: View {
    
    @Binding var showNewTask: Bool
        
        var body: some View {
            
            HStack {
                Text("Todo things")
                    .font(.system(size: 40, weight: .black))
                
                Spacer()
                
                Button(action: {
                    
                    self.showNewTask = true
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.largeTitle).foregroundColor(.blue)
                }
            }
            .padding()
        }
}

// no data view
struct NoDataView: View {
    var body: some View {
        
        Image("image01")
            .resizable()
            .scaledToFit()
    }
}



//private let itemFormatter: DateFormatter = {
//    let formatter = DateFormatter()
//    formatter.dateStyle = .short
//    formatter.timeStyle = .medium
//    return formatter
//}()
