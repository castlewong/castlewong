//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Castle Wong on 2022/10/5.
//

import SwiftUI

// THE @main attribute identifies the app's entry point.
@main
struct LandmarksApp: App {
    @StateObject private var modelData = ModelData()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(modelData)
        }
    }
}
