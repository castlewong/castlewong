//
//  ContentView.swift
//  Landmarks
//
//  Created by Castlw Wong on 2022/10/5.
//

import SwiftUI

struct ContentView: View {
    @State private var selecion: Tab = .featured
    
    enum Tab {
        case featured
        case list
    }
    
    var body: some View {
        TabView(selection: $selecion) {
            
        CategoryHome()
                .tabItem {
                    Label("Featured", systemImage: "star")
                }
                .tag(Tab.featured)
        
        LandmarkList()
                .tabItem {
                    Label("List", systemImage: "list.star")
                }
                .tag(Tab.list)
            
            // embed dynamically generated list of landmarks
            // in a NavigationView
                
            // Oh this is called .navigationTitle !!!
            // I love .navigationTitle !!! love this modifier method
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(ModelData())
    }
}
