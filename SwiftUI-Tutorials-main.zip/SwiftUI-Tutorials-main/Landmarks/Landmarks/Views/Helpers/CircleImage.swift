//
//  CircleImage.swift
//  Landmarks
//
//  Created by Castle Wong on 2022/10/6.
//

import SwiftUI

struct CircleImage: View {
    // add a stored image prperty to CircleImage
    var image: Image
    
    var body: some View {
        image
            .clipShape(Circle())
            .overlay {
                Circle().stroke(.white, lineWidth: 4)
            }
            .shadow(radius: 7)
//        Image("turtlerock") ⬅️ old design
//            .clipShape(Circle())
//            .overlay {
////              Circle().stroke(.green, lineWidth: 8)
//                Circle().stroke(.white, lineWidth: 8)
//            }
//            .shadow(radius: 7)
            
    }
}

struct CircleImage_Previews: PreviewProvider {
    static var previews: some View {
        CircleImage(image: Image("turtlerock"))
    }
}
