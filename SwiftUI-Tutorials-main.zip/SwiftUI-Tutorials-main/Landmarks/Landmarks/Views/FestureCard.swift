//
//  FestureCard.swift
//  Landmarks
//
//  Created by 陈安冉 on 2022/10/17.
//

import SwiftUI

struct FestureCard: View {
    var landmark: Landmark
    
    var body: some View {
        landmark.festureImage?
            .resizable()
            .aspectRatio(3 / 2, contentMode: .fit)
            .overlay {
                TextOverlay(landmark: landmark)
            }
    }
}

struct TextOverlay: View {
    var landmark: Landmark
    
    var gradient: LinearGradient {
        .linearGradient(
            Gradient(colors: [.orange.opacity(0.4), .black.opacity(0)]), startPoint: .bottom, endPoint: .center)
    }
    
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            gradient
            VStack(alignment: .leading) {
                Text(landmark.name)
                    .font(.title)
                    .bold()
                Text(landmark.park)
            }
            .padding()
        }
        .foregroundColor(.white)
    }
}

struct FestureCard_Previews: PreviewProvider {
    static var previews: some View {
        FestureCard(landmark: ModelData().features[0])
    }
}
