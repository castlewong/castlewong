//
//  LandmarkList.swift
//  Landmarks
//
//  Created by Castle Wong on 2022/10/7.
//

import SwiftUI

struct LandmarkList: View {
    @EnvironmentObject var modelData: ModelData
    @State private var showFavoritesOnly = false
    
    var filteredLandmarks: [Landmark] {
//      landmarks.filter { landmark in // why add a case为甚要加sFO这个条件 因为有时候用户想只看最爱
        modelData.landmarks.filter { landmark in
            (!showFavoritesOnly || landmark.isFavorite) // 左边为只看
        }
    }
    
    var body: some View {
        NavigationView {
            //            List (filteredLandmarks) { landmark in
            //
            // ", id: \.id" use left to make data identifiable 2 ways one is passing along with your data
            // a key path to a property that uniquely identifies each element or making your data type conform to the Identifiable protocol.
            // Cannot convert value 'showFavoritesOnly' of type 'Bool' to expected type 'Binding<Bool>', use wrapper instead ⬇️
            List {
                Toggle(isOn: $showFavoritesOnly) {
                    Text("Favorites Only")
                }.foregroundColor(.orange).shadow(radius: 6)
                
                ForEach(filteredLandmarks) { landmark in
                    NavigationLink {
                        LandmarkDetail(landmark: landmark)
                    } label: {
                        LandmarkRow(landmark: landmark)
                    }
                }
            }
            .navigationTitle("Landmarks")
        }
    }
}

struct LandmarkList_Previews: PreviewProvider {
    static var previews: some View {
        LandmarkList()
//          .enviromentObject(ModelData()) // missing a 'n'
            .environmentObject(ModelData())
    }
}
