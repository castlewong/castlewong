//
//  RotaryBadgeApp.swift
//  RotaryBadge
//
//  Created by 陈安冉 on 2022/10/18.
//

import SwiftUI

@main
struct RotaryBadgeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
