//
//  ContentView.swift
//  RotaryBadge
//
//  Created by 陈安冉 on 2022/10/18.
//

import SwiftUI
import Foundation

struct ContentView: View {
    
    @State private var starColor:Color = .red
    @State var animation = 0.0
    
    var body: some View {
        

        ZStack {
//            Color.black.opacity(0.9).edgesIgnoringSafeArea(.all)
            badgeView()
        }
        .rotation3DEffect(.degrees(animation), axis: (x: 0.1 , y: 1, z: 0.1))
        .onTapGesture {
            withAnimation(.interpolatingSpring(stiffness: 20, damping: 4)) {
                self.animation += 360
            }
        }
    }
}

struct badgeView: View {
    var width: Double = UIScreen.main.bounds.width

    var body: some View {
    ZStack{
        
//        Circle()
//            .fill(Color(.orange).opacity(0.2))
        
        
        // out circle
Circle()
            .frame(width: 160, height: 160)
            .foregroundColor(.purple.opacity(0.4))
            .shadow(radius: 20, y: 0.5)

            .overlay(Circle().stroke(Color.purple.opacity(0.5), lineWidth: 5))
            
        
        ForEach(0..<60, id: \.self) { i in
            
            Text("🌕")
                .offset(y: (width - 296) / 2)
                .rotationEffect(.init(degrees: Double(i) * 30))
        }
        // center moon
        Image(systemName: "moon.fill")
            
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 80)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.purple, lineWidth: 7)
            )
//            .shadow(radius: 15)
            .foregroundColor(Color.purple)
    }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
