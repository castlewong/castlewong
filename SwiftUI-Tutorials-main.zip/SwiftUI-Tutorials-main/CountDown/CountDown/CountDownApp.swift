//
//  CountDownApp.swift
//  CountDown
//
//  Created by 陈安冉 on 2022/10/17.
//

import SwiftUI

@main
struct CountDownApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
