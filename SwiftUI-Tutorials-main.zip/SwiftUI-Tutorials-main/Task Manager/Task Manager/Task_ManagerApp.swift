//
//  Task_ManagerApp.swift
//  Task Manager
//
//  Created by 陈安冉 on 2022/11/20.
//

import SwiftUI

@main
struct Task_ManagerApp: App {
    let persistenceController = PersistenceController.Task_Manager

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
