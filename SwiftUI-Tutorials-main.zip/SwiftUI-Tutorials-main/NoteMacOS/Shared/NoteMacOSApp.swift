//
//  NoteMacOSApp.swift
//  Shared
//
//  Created by 陈安冉 on 2022/10/25.
//

import SwiftUI

@main
struct NoteMacOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        // hiding title bar
        // use xcode 13 the app will work for macOS 11, 12 iOS 14, 15
        #if os(macOS)
        .windowStyle(HiddenTitleBarWindowStyle())
        #endif
        
    }
}
