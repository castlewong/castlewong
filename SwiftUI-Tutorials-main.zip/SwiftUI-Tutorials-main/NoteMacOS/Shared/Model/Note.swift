//
//  Note.swift
//  NoteMacOS (iOS)
//
//  Created by 陈安冉 on 2022/10/25.
//

import SwiftUI

// note model and sample notes
struct Note: Identifiable {
    var id = UUID().uuidString
    var note: String
    var date: Date
    var cardColor: Color
}

func getSampleDate(offset: Int) -> Date {
    let calender = Calendar.current
    
    let date = calender.date(byAdding: .day, value: offset, to: Date())

    return date ?? Date()
    
}

var notes: [Note] = [
    
    Note(note: "The beginning of screenless design UI jobs to be taken...", date: getSampleDate(offset: 1), cardColor: Color("Skin")),
  
    Note(note: "The beginning of screenless design UI jobs to be taken...", date: getSampleDate(offset: -10), cardColor: Color("Purple")),
    
    Note(note: "The beginning of screenless design UI jobs to be taken...", date: getSampleDate(offset: -15), cardColor: Color("Green")),
    
    Note(note: "The beginning of screenless design UI jobs to be taken...", date: getSampleDate(offset: 10), cardColor: Color("Blue")),
    
    Note(note: "The beginning of screenless design UI jobs to be taken...", date: getSampleDate(offset: -3), cardColor: Color("Orange")),
]
