//
//  ContentView.swift
//  Shared
//
//  Created by 陈安冉 on 2022/10/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        Home()
            .buttonStyle(BorderlessButtonStyle())
            .textFieldStyle(PlainTextFieldStyle())
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
