//
//  Task.swift
//  Task Manager Prepare
//
//  Created by KIOXIA on 2022/11/27.
//

import SwiftUI

struct Task: Identifiable{
    var id = UUID().uuidString
    var taskTitle: String
    var taskDescription: String
    var taskDate: Date
}
