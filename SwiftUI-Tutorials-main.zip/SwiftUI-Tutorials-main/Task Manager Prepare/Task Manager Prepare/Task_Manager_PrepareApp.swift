//
//  Task_Manager_PrepareApp.swift
//  Task Manager Prepare
//
//  Created by KIOXIA on 2022/11/27.
//

import SwiftUI

@main
struct Task_Manager_PrepareApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
