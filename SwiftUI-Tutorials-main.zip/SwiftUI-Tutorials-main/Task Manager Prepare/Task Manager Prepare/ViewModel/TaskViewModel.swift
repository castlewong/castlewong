//
//  TaskViewModel.swift
//  Task Manager Prepare
//
//  Created by KIOXIA on 2022/11/27.
//

import SwiftUI

class TaskViewModel: ObservableObject{
    
    // sample tasks
    @Published var storedTasks: [Task] = [
        
        Task(taskTitle: "Meeting", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669732081)),
        Task(taskTitle: "Fooding", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669814745)),
        Task(taskTitle: "Eating", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669814745)),
        Task(taskTitle: "Hanging Out", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669814745)),
        Task(taskTitle: "Writing", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669814245)),
        Task(taskTitle: "Testing", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669822633)),
        Task(taskTitle: "Coding", taskDescription: "Discuss sth.", taskDate: .init(timeIntervalSince1970: 1669821945)),
        
    ]
    
    // MARK: current week days
    @Published var currentWeek: [Date] = []
    
    // MARK: current day
    @Published var currentDay: Date = Date()
    
    // MARK: filtering today tasks
    @Published var filteredTasks: [Task]?
    
    // MARK: Intializing
    init(){
        fetchCurrentWeek()
        filterTodayTasks()
    }
    
    // MARK: Filter Today Tasks
    func filterTodayTasks(){
        
        DispatchQueue.global(qos: .userInteractive).async {
            
            let calendar = Calendar.current
            
            let filtered = self.storedTasks.filter{
                return calendar.isDate($0.taskDate, inSameDayAs: self.currentDay)
            }
                .sorted { task1, task2 in
                         return task2.taskDate > task1.taskDate
                         }
            
            DispatchQueue.main.async {
                withAnimation{
                    self.filteredTasks = filtered
                }
            }
        }
    }
    
    func fetchCurrentWeek(){
        
        let today = Date()
        let calendar = Calendar.current
        
        let week = calendar.dateInterval(of: .weekOfMonth, for: today)
        
        guard let firstWeekDay = week?.start else{
            return
        }
        
        (1...7).forEach { day in
            
            if let weekday = calendar.date(byAdding: .day, value: day, to: firstWeekDay){
                currentWeek.append(weekday)
            }
        }
    }
    
    // MARK: Extracting date
    func extractDate(date: Date, format: String) -> String{
        let formatter = DateFormatter()
        
        formatter.dateFormat = format
        
        return formatter.string(from: date)
    }
    
    // MARK: checking if current date is today
    func isToday(date: Date) -> Bool {
        let calendar = Calendar.current
        
        return calendar.isDate(currentDay, inSameDayAs: date)
    }
    
    // MARK: Checking if the currentHour is task Hour
    func isCurrentHour(date: Date) -> Bool {
        
        let calendar = Calendar.current
        
        let hour = calendar.component(.hour, from: date)
        
        let currentHour = calendar.component(.hour, from: Date())
        
        return hour == currentHour
    }
}
