//
//  NewToDoView.swift
//  ToDoList
//
//  Created by Castle Wong on 31/8/2020.
//

import SwiftUI

struct NewMemoryView: View {
    
    @Environment(\.managedObjectContext) var context
    
    @Binding var isShow: Bool

//    @State var content: String
    @Binding var content: String
//    @State var kind: Kind
    @Binding var kind: Kind
    @State var isEditing = false
    
    @Binding var writeTime: String
//    @Binding var memoryItems: [MemoryItem]

    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(alignment: .leading) {
                HStack {
                    Text("What's in MyMind ?")
                        .font(.system(.title, design: .rounded))
                        .bold()
                    Spacer()
                    Button(action: {
                        self.isShow = false
                    }) {
                        Image("xmark")
                            .foregroundColor(.black)
                            .font(.headline)
                    }
                }
                
                TextField("What's in MyMind ?", text: $content, onEditingChanged: { (editingChanged) in
                    
                    self.isEditing = editingChanged
                    
                })
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding(.bottom)
                
                HStack {
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .normal ? Color.gray.opacity(0.4) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                            .overlay(
                                Circle().stroke(Color.gray.opacity(0.6), lineWidth: 4)
                            )
                            .onTapGesture {
                                self.kind = .normal
                            }
                    }
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .happy ? Color.yellow.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                            .overlay(
                                Circle().stroke(Color.yellow, lineWidth: 4)
                            )
                            .onTapGesture {
                                self.kind = .happy
                            }
                    }
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .sad ? Color.blue.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                            .overlay(
                                Circle().stroke(Color.blue, lineWidth: 4)
                            )
                            .onTapGesture {
                                self.kind = .sad
                            }
                    }
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .disgusting ? Color.green.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                            .overlay(
                                Circle().stroke(Color.green, lineWidth: 4)
                            )
                            .onTapGesture {
                                self.kind = .disgusting
                            }
                    }
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .angry ? Color.red.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                            .overlay(
                                Circle().stroke(Color.red, lineWidth: 4)
                            )
                            .onTapGesture {
                                self.kind = .angry
                            }
                    }
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .fearful ? Color.purple.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                            .overlay(
                                Circle().stroke(Color.purple, lineWidth: 4)
                            )
                            .onTapGesture {
                                self.kind = .fearful
                            }
                    }
                    
                    
                    
                }
                .padding(.bottom, 10)
                
                // Save button for adding the todo item
                Button(action: {
                    
                    if self.content.trimmingCharacters(in: .whitespaces) == "" {
                        return
                    }
                    
                    self.isShow = false
                    self.addMemory(content: self.content, kind: self.kind, writeTime: getCurrentTimeWithoutSS())
                     
                }) {
                    Text("Save")
                        .font(.system(.headline, design: .rounded))
                        .frame(minWidth: 0, maxWidth: .infinity)
                        .padding()
                        .foregroundColor(.white)
                        .background(colorOfSaveBTN(for: kind))
                        .cornerRadius(10)
                }
                .padding(.bottom)
                
                
                
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10, antialiased: true)
            .offset(y: isEditing ? -320 : 0)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
    
    private func getCurrentTimeWithoutSS() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm"
        return dateformatter.string(from: Date())
    }
    
    private func colorOfSaveBTN(for kind: Kind) -> Color {
        switch kind {
        case .angry: return .red
        case .normal: return .gray.opacity(0.6)
        case .fearful: return .purple
        case .sad:
            return .blue
        case .happy:
            return .yellow
        case .disgusting:
            return .green
        }
    }
    
    private func addMemory(content: String, kind: Kind, isComplete: Bool = false, writeTime: String) {
        
        let memoryEntry = MemoryItem(context: context)
        memoryEntry.id = UUID()
        memoryEntry.content = content
        memoryEntry.kind = kind
        memoryEntry.isComplete = isComplete
        memoryEntry.writeTime = writeTime
        
        do {
            try context.save()
        } catch {
            print(error)
        }
    }
//    
//       private func neweditMemory(item: MemoryItem) {
//            if let id = context.firstIndex(where: { $0.id == item.id }) {
//                MemoryItem(context: context)[id] = item
//    
//                do {
//                    try context.save()
//                } catch {
//                    print(error)
//                }
//            }
//        }

}



struct NewMemoryView_Previews: PreviewProvider {
    static var previews: some View {
        NewMemoryView(isShow: .constant(true), content: .constant(""), kind: .constant(.normal), writeTime: .constant(""))
    }
}


