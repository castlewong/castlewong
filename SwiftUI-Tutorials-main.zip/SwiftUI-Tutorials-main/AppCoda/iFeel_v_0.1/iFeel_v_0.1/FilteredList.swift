////
////  FilteredList.swift
////  iFeel_v_0.1
////
////  Created by 陈安冉 on 2022/11/20.
////
//
//
//struct FilteredList: View {
//
//    @Environment(\.managedObjectContext) var context
//
//    @Binding var searchText: String
//
//    var fetchRequest: FetchRequest<MemoryItem>
//    var memoryItems: FetchedResults<MemoryItem> {
//        fetchRequest.wrappedValue
//    }
//    
//    init(_ searchText: Binding<String>) {
//        self._searchText = searchText
//        
//        let predicate = searchText.wrappedValue.isEmpty ? NSPredicate(value: true) : NSPredicate(format: "name CONTAINS[c] %@", searchText.wrappedValue)
//        
//        self.fetchRequest = FetchRequest(entity: MemoryItem.entity(),
//                                         sortDescriptors: [ NSSortDescriptor(keyPath: \MemoryItem.kindNum, ascending: false) ],
//                                         predicate: predicate,
//                                         animation: .default)
//    }
//    
//    var body: some View {
//        
//        ZStack {
//            List {
//                    
//                ForEach(memoryItems) { memoryItem in
//                    MemoryListRow(memoryItem: memoryItem, kind: .normal)
//                }
//                .onDelete(perform: deleteTask)
//                                       
//            }
//            
//            if memoryItems.count == 0 {
//                NoDataView()
//            }
//        }
//        
//        
//    }
//    
//    private func deleteTask(indexSet: IndexSet) {
//        for index in indexSet {
//            let itemToDelete = memoryItems[index]
//            context.delete(itemToDelete)
//        }
//        
//        do {
//            try context.save()
//        } catch {
//            print(error)
//        }
//    }
//}



//struct FilteredList: View {
//    
//    @Environment(\.managedObjectContext) var context
//    
//    @Binding var searchText: String
//    
//    var fetecRequest: FetchRequest<MemoryItem>
//    var memoryItems: FetchedResults<MemoryItem> {
//        fetecRequest.wrappedValue
//    }
//    
//    
//    init(_ searchText: Binding<String>) {
//        self._searchText = searchText
//        
//        let predicate = searchText.wrappedValue.isEmpty ? NSPredicate(value: true) : NSPredicate(format: "name CONTAINS[c] %@", searchText.wrappedValue)
//        
//        self.fetecRequest = FetchRequest(entity: MemoryItem.entity(), sortDescriptors: [ NSSortDescriptor(keyPath: \MemoryItem.kindNum, ascending: false) ], predicate: predicate, animation: .default)
//    }
//    
//    var body: some View {
//        
//        ZStack {
//            ForEach(memoryItems) { memoryItem in
//                MemoryListRow(memoryItem: memoryItem, kind: .normal)
//            }
//            .onDelete(perform: deleteTask)
//            
//            
//            if memoryItems.count == 0 {
//                NoDataView()
//            }
//        }
//    }
//    private func deleteTask(indexSet: IndexSet) {
//        for index in indexSet {
//            let itemToDelete = memoryItems[index]
//            context.delete(itemToDelete)
//        }
//        
//        do {
//            try context.save()
//        } catch {
//            print(error)
//        }
//    }
//}
