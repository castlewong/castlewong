////
////  ViewModel.swift
////  ToDoList
////
////  Created by 陈安冉 on 2022/11/19.
////  Model for declare pompts of data model ViewModel to achieve foundmental funcs CURD
//// below from qiuyu
//
//import Foundation
//import Combine // provide a declarative way for CURD
//import SwiftUI
//
//class ViewModel: ObservableObject { // be able to bind self defined objects to use
//    
//    @Environment(\.managedObjectContext) var context
//
//    
//    @Published var memoryModels = [MemoryItem]()
//    
//    @Published var writeTime: String = ""
//    @Published var kindNum: Int32 = 0
//    @Published var content: String = ""
//    @Published var title: String = ""
//    
//    @Published var isAdd: Bool = true
//    @Published var showNewEntry: Bool = false
//    @Published var showEditMemoryView: Bool = false
//
//    
//    func newaddMemory(content: String, kind: Kind, isComplete: Bool = false, writeTime: String) {
//        
//        let memoryEntry = MemoryItem(context: context)
//        memoryEntry.id = UUID()
//        memoryEntry.content = content
//        memoryEntry.kind = kind
//        memoryEntry.isComplete = isComplete
//        memoryEntry.writeTime = writeTime
//        
//        do {
//            try context.save()
//        } catch {
//            print(error)
//        }
//    }
//    
//    func neweditMemory(item: MemoryItem) {
//        if let id = memoryModels.firstIndex(where: { $0.id == item.id }) {
//            memoryModels[id] = item
//            
//            do {
//                try context.save()
//            } catch {
//                print(error)
//            }
//        }
//    }
//}
