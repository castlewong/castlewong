//
//  iFeel_v_0_1App.swift
//  iFeel_v_0.1
//
//  Created by 陈安冉 on 2022/11/16.
//

import SwiftUI
// Thread 1: Fatal error: UnsafeRawBufferPointer with negative count Thread 1: "-[iFeel_v_0_1.MemoryItem name]: unrecognized selector sent to instance 0x6000035dd090"
@main
struct iFeel_v_0_1App: App {
    
    let persistenceController = PersistenceController.shared
    
    // from qiuyu
//    @StateObject var viewModel: ViewModel = ViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
//                .environmentObject(viewModel)
        }
    }
}
