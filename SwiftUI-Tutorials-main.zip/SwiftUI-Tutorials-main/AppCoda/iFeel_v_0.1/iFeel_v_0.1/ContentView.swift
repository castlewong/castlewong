//
//  ContentView.swift
//  iFeel_v_0.1
//
//  Created by Castle on 2022/11/16.
//



import SwiftUI

struct ContentView: View {
    
    @Environment(\.managedObjectContext) var context
    
    @FetchRequest(
        entity: MemoryItem.entity(),
        sortDescriptors: [ NSSortDescriptor(keyPath: \MemoryItem.kindNum, ascending: false) ])
    var MemoryItems: FetchedResults<MemoryItem>
    
    @State private var newItemContent: String = ""

    @State private var newItemKind: Kind = .normal
    
    @State private var showNewEntry = false
    
    @State private var newItemTime: String = ""
    
    @State private var searchText = ""
    
    var body: some View {
        
        ZStack {
            ScrollView {
            VStack {
//                SearchBar(text: $searchText)
//                FilteredList($searchText)
                    VStack {
                        ForEach(MemoryItems) { MemoryItem in
                            MemoryListRow(memoryItem: MemoryItem, kind: newItemKind)
                        }
//                        .shadow(color: Color.yellow, radius: 25, x: -13, y: 3)
                        .onDelete(perform: deleteTask)
                    }
                    .ignoresSafeArea()
//                    Spacer()

                }
            }
            .shadow(color: Color.gray.opacity(0.6), radius: 9, x: -4, y: 6)
            .padding()
            .padding(.top, 25)
            .rotation3DEffect(Angle(degrees: showNewEntry ? 5 : 0), axis: (x: 1, y: 0, z: 0))
            .offset(y: showNewEntry ? -50 : 0)
            .animation(.easeInOut)
            
            VStack {
                Spacer()
                Button(action: {
                    self.showNewEntry = true
                    self.newItemContent = ""
                }) {
                    MagicWheel()
                }
                .padding()
            }
            
            if MemoryItems.count == 0 {
                NoDataView()
            }
            // Display the "Add new todo" view
            if showNewEntry {
                BlankView(bgColor: .black)
                    .opacity(0.3)
                    .onTapGesture {
                        self.showNewEntry = false
                    }
                
                NewMemoryView(isShow: $showNewEntry, content: $newItemContent, kind: $newItemKind, writeTime: $newItemTime)
                    .transition(.move(edge: .bottom))
                    .animation(.interpolatingSpring(stiffness: 200.0, damping: 25.0, initialVelocity: 10.0))
            }
        }
        .edgesIgnoringSafeArea(.bottom)
    }
    
    private func deleteTask(indexSet: IndexSet) {
        for index in indexSet {
            let itemToDelete = MemoryItems[index]
            context.delete(itemToDelete)
        }

        DispatchQueue.main.async {
            do {
                try context.save()
                
            } catch {
                print(error)
            }
        }
    }
    
    private func color(for kind: Kind) -> Color {
        switch kind {
        case .angry: return .red
        case .normal: return Color("NormalColor")
        case .fearful: return .purple
        case .sad:
            return .blue
        case .happy:
            return .yellow
        case .disgusting:
            return .green
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
//            .preferredColorScheme(.dark)
            .preferredColorScheme(.light)
    }
}

struct BlankView : View {

    var bgColor: Color

    var body: some View {
        VStack {
            Spacer()
        }
        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
        .background(bgColor)
        .edgesIgnoringSafeArea(.all)
    }
}

struct NoDataView: View {
    var body: some View {
        VStack {
            Image("welcome")
                .resizable()
            .scaledToFit()
            Text("What's in MyMind?")
        }
    }
}

struct MemoryListRow: View {
    
//    @EnvironmentObject var viewModel: ViewModel
    
    @Environment(\.managedObjectContext) var context
    
    @ObservedObject var memoryItem: MemoryItem
    
    @State var kind: Kind

    var body: some View {
//        Toggle(isOn: self.$memoryItem.isComplete) {
        
        VStack(alignment: .leading, spacing: 6.0) {
            HStack {
//                Text(getCurrentTimeWithoutSS())
                Text(memoryItem.writeTime)
                    .font(.system(size: 14))
                    .fontWeight(.regular)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 5)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(.secondary, lineWidth: 1)
                    )
            }
//            .padding(.horizontal, 13)
            .padding(.top, 12)
            .padding(.horizontal, 16)
            HStack {
                Text(memoryItem.content)
                    .font(.body)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                .foregroundColor(.primary)
            }
            .padding(.horizontal, 14)
            Spacer()
        }
//        .onTapGesture {
////  MARK: from qiuyu
//            self.viewModel.isAdd = false
//            self.viewModel.showEditMemoryView = true
//        }
        .ignoresSafeArea(.all)
        .frame(height: 100.0)
        .background(color(for: kind).opacity(0.81))
//        .background(Color.gray.opacity(0.28))
        .cornerRadius(28.0)
        

//        .shadow(color: Color.black.opacity(0.38), radius: 10, x: 0, y: 0)
        .onReceive(memoryItem.objectWillChange, perform: { _ in
            if self.context.hasChanges {
                try? self.context.save()
            }
        })
    }
    
    private func color(for kind: Kind) -> Color {
        switch kind {
        case .angry: return .red
        case .normal: return Color("NormalColor")
        case .fearful: return .purple
        case .sad:
            return .blue
        case .happy:
            return .yellow
        case .disgusting:
            return .green
        }
    }
    
    func getCurrentTime() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm:ss"
        return dateformatter.string(from: Date())
    }
    
    
//    func getCurrentTimeWithoutSS() -> String {
//        let dateformatter = DateFormatter()
//        dateformatter.dateFormat = "HH:mm"
//        return dateformatter.string(from: Date())
//    }

}
