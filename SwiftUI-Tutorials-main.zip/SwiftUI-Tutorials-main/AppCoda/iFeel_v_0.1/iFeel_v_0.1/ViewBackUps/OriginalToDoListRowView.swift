////
////  OriginalToDoListRowView.swift
////  iFeel_v_0.1
////
////  Created by 陈安冉 on 2022/11/17.
////
//
//import SwiftUI
//
//struct OriginalToDoListRowView: View {
//    
//    @Environment(\.managedObjectContext) var context
//    
//    @ObservedObject var memoryItem: MemoryItem
//    
//    var body: some View {
//        
//        
//        
//        
//        HStack {
//            Text(self.memoryItem.content)
//                .strikethrough(self.memoryItem.isComplete, color: .black)
//                .bold()
//                .animation(.default)
//                .foregroundColor(.blue)
//            Spacer()
//            
//            ZStack(alignment: .center) {
//                Circle()
//                    .foregroundColor(self.color(for: self.memoryItem.kind).opacity(0.7))
//                    .frame(width: 20, height: 20, alignment: .center)
//                .overlay(
//                    Circle().stroke(self.color(for: self.memoryItem.kind), lineWidth: 4)
//                )
//            }
//        }
//.onReceive(memoryItem.objectWillChange, perform: { _ in
//    if self.context.hasChanges {
//        try? self.context.save()
//    }
//})
//        
//        
//        
//    }
//}
//
//
//
//struct OriginalToDoListRowView_Previews: PreviewProvider {
//    static var previews: some View {
//        OriginalToDoListRowView(, memoryItem: MemoryItem)
//    }
//}
