//
//  CoreDataTestSecondVersionApp.swift
//  CoreDataTestSecondVersion
//
//  Created by KIOXIA on 2022/12/13.
//

import SwiftUI

@main
struct CoreDataTestSecondVersionApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
