//
//  ProgressRingViewApp.swift
//  ProgressRingView
//
//  Created by 陈安冉 on 2022/11/5.
//

import SwiftUI

@main
struct ProgressRingViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
