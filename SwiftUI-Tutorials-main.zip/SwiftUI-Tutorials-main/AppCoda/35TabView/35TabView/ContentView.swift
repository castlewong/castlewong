//
//  ContentView.swift
//  35TabView
//
//  Created by 陈安冉 on 2022/10/30.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = 0
    
    var body: some View {
        ZStack(alignment: .topTrailing) {

            NavigationView {
                TabView(selection: $selection) {
                    List(1...10, id: \.self) { index in
                        NavigationLink(
                            destination:
                                VStack {
                                    Text("Item #\(index) Details")
                                    Text("Test what can be placed in destination")
                                }
                            ,
                            label: {
                                Text("Item #\(index)")
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                            })
                        
                    }
                    .tabItem {
                        Image(systemName: "house.fill")
                        Text("Home")
                    }
                    .tag(0)
                    
                    Text("bookmark, Tab!")
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                        .tabItem {
                            Image(systemName: "bookmark.fill")
                            Text("Bookmark")
                        }
                        .tag(1)
                    
                    
                    Text("video, Tab!")
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                        .tabItem {
                            Image(systemName: "video.fill")
                            Text("Video")
                        }
                        .tag(2)
                    
                    
                    Text("profile, Tab!")
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                        .tabItem {
                            Image(systemName: "person")
                            
                            Text("Profile")
                                .font(.system(size: 40))
                        }
                        .tag(3)
                    
                }
                .accentColor(.red)
                .onAppear() {
                    UITabBar.appearance().barTintColor = .black
                }
                
                .navigationTitle("TabView Demo")
                
                
            }
            
            
//            Button(action: {
//                selection = (selection + 1) % 4
//            }) {
//                Text("Next")
//                    .font(.system(.headline, design: .rounded))
//                    .padding()
//                    .foregroundColor(.white)
//                    .background(Color.red)
//                    .cornerRadius(10)
//                    .padding()
////                  .offset(y: 28)
//            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
