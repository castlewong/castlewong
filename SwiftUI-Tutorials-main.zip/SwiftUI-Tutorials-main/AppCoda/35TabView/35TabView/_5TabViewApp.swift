//
//  _5TabViewApp.swift
//  35TabView
//
//  Created by 陈安冉 on 2022/10/30.
//

import SwiftUI

@main
struct _5TabViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
