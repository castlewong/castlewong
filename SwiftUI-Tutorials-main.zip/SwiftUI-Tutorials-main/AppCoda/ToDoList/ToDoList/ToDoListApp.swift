//
//  ToDoListApp.swift
//  ToDoList
//
//  Created by Simon Ng on 31/8/2020.
//

import SwiftUI

let persistenceController = PersistenceController.shared

@main
struct ToDoListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            // MARK: inject the managed object into the environment of contentview, this allow us to easily access the context in the content view for managing the data in the database
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
