//
//  ToDoItem.swift
//  ToDoList
//
//  Created by Simon Ng on 31/8/2020.
//

import Foundation
import CoreData

enum Priority: Int {
    case low = 0
    case normal = 1
    case high = 2
}

public class ToDoItem: NSManagedObject {
    // MARK: NSManaged tells the compiler that the property is taken care by Core Data.
    @NSManaged public var id: UUID
    @NSManaged public var name: String
    @NSManaged public var priorityNum: Int32
    @NSManaged public var isComplete: Bool
}

extension ToDoItem: Identifiable {
    var priority: Priority {
        get {
            return Priority(rawValue: Int(priorityNum)) ?? .normal
        }
        
        set {
            self.priorityNum = Int32(newValue.rawValue)
        }
    }
}

//class ToDoItem: ObservableObject, Identifiable {
//    var id = UUID()
//    @Published var name: String = ""
//    @Published var priority: Priority = .normal
//    @Published var isComplete: Bool = false
//
//    init(name: String, priority: Priority = .normal, isComplete: Bool = false) {
//        self.name = name
//        self.priority = priority
//        self.isComplete = isComplete
//    }
//}


