//
//  MagicWheel.swift
//  ToDoList
//
//  Created by 陈安冉 on 2022/11/15.
//

import SwiftUI

struct MagicWheel: View {
    var body: some View {
        VStack {
                Circle() // magic wheel
                    .strokeBorder(
                        AngularGradient(gradient: Gradient(colors: [.red, .orange, .orange, .yellow, .green, .green, .blue, .blue, .purple, .purple, .red]), center: .center, startAngle: .degrees(360)), lineWidth: 4.2
                    )
                    .background(Circle().fill(.white .opacity(0.7)))
                    .shadow(color: .gray.opacity(0.6), radius: 5, x: -3, y: 3)
                    .frame(width: 55, height: 55)
            
        
}    }
}

struct MagicWheel_Previews: PreviewProvider {
    static var previews: some View {
        MagicWheel()
    }
}
