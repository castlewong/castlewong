//
//  NewToDoView.swift
//  ToDoList
//
//  Created by Simon Ng on 31/8/2020.
//

import SwiftUI

struct NewMemoryView: View {
    
    @Environment(\.managedObjectContext) var context
    
    @Binding var isShow: Bool
    
    @State var content: String
    @State var kind: Kind
    @State var isEditing = false
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(alignment: .leading) {
                HStack {
                    Text("What's in MyMind ?")
                        .font(.system(.title, design: .rounded))
                        .bold()
                    
                    Spacer()
                    
                    Button(action: {
                        self.isShow = false
                        
                    }) {
                        Image("xmark")
                            .foregroundColor(.black)
                            .font(.headline)
                    }
                }
                
                TextField("What's in MyMind ?", text: $content, onEditingChanged: { (editingChanged) in
                    
                    self.isEditing = editingChanged
                    
                })
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.bottom)
                
//                Text("Priority")
//                    .font(.system(.subheadline, design: .rounded))
//                    .padding(.bottom)
                
                HStack {
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .sad ? Color.blue.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                        .overlay(
                            Circle().stroke(Color.blue, lineWidth: 4)
                        )
                        .onTapGesture {
                            self.kind = .sad
                        }
                    }
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .fearful ? Color.green.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                        .overlay(
                            Circle().stroke(Color.green, lineWidth: 4)
                        )
                        .onTapGesture {
                            self.kind = .fearful
                        }
                    }
                    
                    ZStack(alignment: .center) {
                        Circle()
                            .fill(kind == .angry ? Color.red.opacity(0.7) : Color.clear)
                            .frame(width: 24, height: 24, alignment: .center)
                        .overlay(
                            Circle().stroke(Color.red, lineWidth: 4)
                        )
                        .onTapGesture {
                            self.kind = .angry
                        }
                    }
                    
                    
                    Text("Sad")
                        .font(.system(.headline, design: .rounded))
                        .padding(10)
                        .background(kind == .sad ? Color.blue : Color(.systemGray4))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        .onTapGesture {
                            self.kind = .sad
                        }
                }
                .padding(.bottom, 30)
                
                // Save button for adding the todo item
                Button(action: {
                    
                    if self.content.trimmingCharacters(in: .whitespaces) == "" {
                        return
                    }
                    
                    self.isShow = false
                    self.addMemory(content: self.content, kind: self.kind)
                    
                }) {
                    Text("Save")
                        .font(.system(.headline, design: .rounded))
                        .frame(minWidth: 0, maxWidth: .infinity)
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.purple)
                        .cornerRadius(10)
                }
                .padding(.bottom)
                
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10, antialiased: true)
            .offset(y: isEditing ? -320 : 0)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
    
    private func addMemory(content: String, kind: Kind, isComplete: Bool = false) {
        
        let memoryEntry = MemoryItem(context: context)
        memoryEntry.id = UUID()
        memoryEntry.content = content
        memoryEntry.kind = kind
        memoryEntry.isComplete = isComplete
        
        do {
            try context.save()
        } catch {
            print(error)
        }
    }
}


struct NewMemoryView_Previews: PreviewProvider {
    static var previews: some View {
        NewMemoryView(isShow: .constant(true), content: "", kind: .normal)
    }
}


