//
//  MemoryItem.swift
//  MemoryList
//
//  Created by Simon Ng on 31/8/2020.
//

import Foundation
import CoreData

enum Kind: Int {
    case normal = 0
    case angry = 1
    case sad = 2
    case happy = 3
    case fearful = 4
    case disgusting = 5
}

public class MemoryItem: NSManagedObject {
    @NSManaged public var id: UUID
    @NSManaged public var name: String
    @NSManaged public var priorityNum: Int32
    @NSManaged public var isComplete: Bool
    @NSManaged public var kindNum: Int32
    @NSManaged public var content: String
}

extension MemoryItem: Identifiable {
    
    var kind: Kind {
        get {
            return Kind(rawValue: Int(kindNum)) ?? .normal
        }
        
        set {
            self.kindNum = Int32(newValue.rawValue)
        }
    }
}
