//
//  ContentView.swift
//  Timer
//
//  Created by KIOXIA on 2022/12/4.
//

import SwiftUI

struct TimerView: View {
    @State private var timeRemaining = 6
    @State private var isRunning = false

    var body: some View {
        VStack {
            Text("\(timeRemaining) seconds remaining")
                .font(.largeTitle)

            HStack {
                Button(action: startTimer) {
                    Text("Start")
                }

                Button(action: pauseTimer) {
                    Text("Pause")
                }

                Button(action: resetTimer) {
                    Text("Reset")
                }
            }
        }
    }

    private func startTimer() {
        isRunning = true

        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            guard self.isRunning else {
                timer.invalidate()
                return
            }

            if self.timeRemaining > 0 {
                self.timeRemaining -= 1
            } else {
                self.isRunning = false
            }
        }
    }

    private func pauseTimer() {
        isRunning = false
    }

    private func resetTimer() {
        isRunning = false
        timeRemaining = 0
    }
}


struct ContentView: View {
    var body: some View {
        TimerView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
