//
//  WeatherView.swift
//  Timer
//
//  Created by KIOXIA on 2022/12/4.
//

import SwiftUI
import CoreLocation


//
//struct WeatherView_Previews: PreviewProvider {
//    static var previews: some View {
//        WeatherView()
//    }
//}


//struct WeatherView: View {
//    // Create a CLLocationManager instance to get the current location
//    let locationManager = CLLocationManager()
//
//    // Create a variable to store the current location
//    @State private var currentLocation: CLLocation?
//
//    var body: some View {
//        // If the current location is available, show the weather information
//        // Otherwise, show a loading indicator
//        if let location = currentLocation {
//            return Text("The weather in \(location) is sunny")
//        } else {
//            return ProgressView("Loading weather information")
//        }
//    }
//
//    init() {
//        // Ask for permission to access the user's location
//        self.locationManager.requestWhenInUseAuthorization()
//
//        // Get the current location
//        self.currentLocation = self.locationManager.location
//    }
//}
//
//
