////
////  AnalogWatchView.swift
////  Timer
////
////  Created by KIOXIA on 2022/12/5.
////
//
//import SwiftUI
//
//struct AnalogWatchView: View {
//    @State private var currentTime = Date()
//    var body: some View {
//        VStack {
//            Text("\(currentTime, formatter: DateFormatter.time)")
//                .font(.system(size: 50))
//                .bold()
//
//            Circle()
//                .stroke(Color.black, lineWidth: 4)
//                .frame(width: 300, height: 300)
//
//            ForEach(0 ..< 12) { num in
//                Text("\(num + 1)")
//                    .font(.system(size: 20))
//                    .offset(x: 110, y: 0)
//                    .rotationEffect(.degrees(Double(num) * 30))
//            }
//
//            Circle()
//                .trim(from: 0, to: 0.85)
//                .stroke(Color.red, lineWidth: 4)
//                .frame(width: 280, height: 280)
//                .rotationEffect(.degrees(self.seconds))
//
//            Circle()
//                .trim(from: 0, to: 0.75)
//                .stroke(Color.blue, lineWidth: 6)
//                .frame(width: 260, height: 260)
//                .rotationEffect(.degrees(self.minutes))
//
//            Circle()
//                .trim(from: 0, to: 0.6)
//                .stroke(Color.black, lineWidth: 8)
//                .frame(width: 240, height: 240)
//                .rotationEffect(.degrees(self.hours))
//        }
//        .onAppear(perform: startTimer)
//    }
//
//    var seconds: Double {
//        return Double(currentTime.second) / 60 * 360
//    }
//
//    var minutes: Double {
//        return Double(currentTime.minute) / 60 * 360 + seconds / 60
//    }
//
//    var hours: Double {
//        return Double(currentTime.hour) / 12 * 360 + minutes / 12
//    }
//
//    func startTimer() {
//        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
//            self.currentTime = Date()
//        }
//    }
//}
//
//
//struct AnalogWatchView_Previews: PreviewProvider {
//    static var previews: some View {
//        AnalogWatchView()
//    }
//}
