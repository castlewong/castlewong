//
//  TimerApp.swift
//  Timer
//
//  Created by KIOXIA on 2022/12/4.
//

import SwiftUI

@main
struct TimerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
