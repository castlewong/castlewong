//
//  ContentView.swift
//  ToDo
//
//  Created by KIOXIA on 2022/12/4.
//

import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    let name: String
    var isCompleted: Bool = false
}

struct TaskList: View {
    @State var tasks = [Task]()
    @State var newTaskName = ""

    var body: some View {
        VStack {
            HStack {
                TextField("New task", text: $newTaskName)
                Button(action: addTask) {
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(.green)
                        .imageScale(.large)
                }
            }
            .padding()

            List {
                ForEach(tasks) { task in
                    HStack {
                        Button(action: {
//                            task.isCompleted.toggle()
                        }) {
                            Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(task.isCompleted ? .green : .gray)
                                .imageScale(.large)
                        }
                        .buttonStyle(PlainButtonStyle())

                        Text(task.name)
                            .strikethrough(task.isCompleted)

                        Spacer()

                        Button(action: {
                            self.removeTask(task)
                        }) {
                            Image(systemName: "trash.fill")
                                .foregroundColor(.red)
                                .imageScale(.large)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
        }
    }

    private func addTask() {
        guard !newTaskName.isEmpty else { return }

        tasks.append(Task(name: newTaskName))
        newTaskName = ""
    }

    private func removeTask(_ task: Task) {
        tasks.removeAll { $0.id == task.id }
    }
}

struct ContentView: View {
    var body: some View {
        TaskList()
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        TaskList()
    }
}
