//
//  ToDoApp.swift
//  ToDo
//
//  Created by KIOXIA on 2022/12/4.
//

import SwiftUI

@main
struct ToDoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
