//
//  AccountView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/10/31.
//

import SwiftUI

struct AccountView: View {
    var body: some View {
        Text("Hello, World!")
            .font(.largeTitle)
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
    }
}
