////
////  dayDiaryView.swift
////  16CustomTabBar
////
////  Created by 陈安冉 on 2022/11/1.
////

import SwiftUI

struct dayDiaryView: View {
    
    @State var entryCount = 1
    @State var showNewEntryView = false
    

    
    var body: some View {
        NavigationView {
            ZStack {
                ZStack {
                    if entryCount == 0 {
                    } else {
                        VStack {
                            ScrollView {
                                VStack {
                                    //                Text("Hello, World!")
                                    //                    .offset(y: -37)
                                    normalMind
                                    happy
                                    sad
                                    fearful
                                    disgusting
                                }
                            }
                        }
                        Button(action: {self.showNewEntryView.toggle() }) {
                            MagicWheel() }
                    }
                }
                .navigationBarTitle("", displayMode: .inline)
            }
            .sheet(isPresented: $showNewEntryView) {
//                entryEditView(showNewEntryView: .constant(true), memoryItems: .constant([]), writeTime: "", title: "test", content: "tets", kindofMind: .angry)
            }
        }
    }
    
    var normalMind: some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                Text("Place Time Here")
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view.")
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.gray.opacity(0.28))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(28.0)
            .shadow(color: Color.black.opacity(0.28), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
    }
    
    var happy: some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                Text("Place Time Here")
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view.")
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
            .padding(.all, 20.0)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.orange.opacity(0.6))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(30.0)
            .shadow(color: Color.orange.opacity(0.7), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
    }
    var sad: some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                Text("Place Time Here")
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view.")
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
            .padding(.all, 20.0)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.blue.opacity(0.6))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(30.0)
            .shadow(color: Color.blue.opacity(0.7), radius: 10, x: -12, y: 10)
            .padding(.horizontal, 20)
        }
    }
    var fearful: some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                Text("Place Time Here")
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view.")
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
            .padding(.all, 20.0)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.purple.opacity(0.7))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(30.0)
            .shadow(color: Color.purple.opacity(0.7), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
    }
    var angry: some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                Text("Place Time Here")
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view.")
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
            .padding(.all, 20.0)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.red.opacity(0.7))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(30.0)
            .shadow(color: Color.red.opacity(0.7), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
    }
    var disgusting: some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                Text("Place Time Here")
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view.")
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
            .padding(.all, 20.0)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.green.opacity(0.7))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(30.0)
            .shadow(color: Color.green.opacity(0.7), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
    }
    
}

struct dayDiaryView_Previews: PreviewProvider {
    static var previews: some View {
        dayDiaryView().preferredColorScheme(.light)

    }
}
