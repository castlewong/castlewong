//
//  TabBar.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/10/31.
//

import SwiftUI

struct TabBar: View {
    @State var selectedTab: Tab = .home
    @State var color: Color = .teal
    @State var tabItemWidth: CGFloat = 0
    
    var body: some View {
        ZStack(alignment: .bottom) {
            
            Group {
                switch selectedTab {
                case .home:
                    ContentView()
                case .explore:
                    AccountView()
                case .notifications:
                    AccountView()
                case .library:
                    AccountView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            HStack {
                buttons
            }
            .padding(.horizontal, 8)
            .padding(.top, 14)
            .frame(height: 88, alignment: .top)
            .background(.ultraThinMaterial, in:
                            RoundedRectangle(cornerRadius: 29, style: .continuous))
            .background(
                background
            )
            .overlay(
            overlay
            )
            .strokeStyle(cornerRadius: 34)
            .frame(maxHeight: .infinity, alignment: .bottom)
//            .padding(.bottom, 12)
            .ignoresSafeArea()
        }
    }
    
    
    var buttons: some View {
        ForEach(tabItems) { item in
            Button {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                    selectedTab = item.tab
                    color = item.color
                }
            } label: {
                VStack(spacing: 0) {
                    Image(systemName: item.icon) // on iOS it's fill on Mac outline
                        .symbolVariant(.fill)
                        .font(.body.bold())
                        .frame(width: 44, height: 29)
                    Text(item.text) // beauty of coding
                        .font(.caption2)
                        .lineLimit(1)
                }
                .frame(maxWidth: .infinity)
            }
            .foregroundStyle(selectedTab == item.tab ? .primary : .secondary)
            .blendMode(selectedTab == item.tab ? .overlay : .normal)
            .overlay(
                GeometryReader { proxy in
//                            Text("\(proxy.size.width)")
//                            tabItemWidth = proxy.size.width
                    Color.clear.preference(key: TabPreferenceKey.self, value: proxy.size.width)
                }
            )
            .onPreferenceChange(TabPreferenceKey.self) {
                value in
                tabItemWidth = value
            }
        }

    }
    
    var background: some View {
        HStack { // a funny way to place the background
            if selectedTab == .library { Spacer()
            }
            if selectedTab == .explore {
                Spacer() }
            if selectedTab == .notifications {
                Spacer()
                Spacer()
            }
            Circle().fill(color).frame(width: tabItemWidth)
            if selectedTab == .home {
                Spacer() }
            if selectedTab == .explore {
                Spacer()
                Spacer()
            }
            if selectedTab == .notifications {
                Spacer() }
        }
            .padding(.horizontal, 8)
    }
    
    var overlay: some View {
        
            HStack { // a funny way to place the background
                if selectedTab == .library { Spacer()
                }
                if selectedTab == .explore {
                    Spacer() }
                if selectedTab == .notifications {
                    Spacer()
                    Spacer()
                }
                Rectangle()
                    .fill(color)
                    .frame(width: 28, height: 5)
                    .cornerRadius(3)
                    .frame(width: tabItemWidth) // why it's not center
                // on my god I'm mad, it's because the phone size, I used the 12 mini and it's fault.
                    .frame(maxHeight: .infinity, alignment: .top)
                
                if selectedTab == .home {
                    Spacer() }
                if selectedTab == .explore {
                    Spacer()
                    Spacer()
                }
                if selectedTab == .notifications {
                    Spacer()
                }
            }
                .padding(.horizontal, 8)
        
    }
}

struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        TabBar()
    }
}
