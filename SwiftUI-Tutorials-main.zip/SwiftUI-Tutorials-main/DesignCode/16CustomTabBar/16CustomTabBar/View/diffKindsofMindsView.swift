//
//  diffKindsofMindsView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/3.
//

import SwiftUI

struct diffKindsofMindsView: View {
    @State var isOpen: Bool = false
    
    var body: some View {
        VStack {
            sad()
                
                .scaledToFill()
        }.frame(width: 22, height: 22)
    }
    
    func sad() -> some View {
        ZStack(alignment: .center) {
            Circle()
                .fill(Color.gray)
                .frame(width: 19, height: 19, alignment: .center)
                .overlay(
            Circle()
                .stroke(Color(.blue), lineWidth: 8)
                .opacity(0.9)
                .frame(width: 80, height: 80, alignment: .center)
            .shadow(color: .white, radius: 30, x: 0, y: 0)
            )
        }
    }
    
}



struct diffKindsofMindsView_Previews: PreviewProvider {
    static var previews: some View {
        diffKindsofMindsView()
    }
}
