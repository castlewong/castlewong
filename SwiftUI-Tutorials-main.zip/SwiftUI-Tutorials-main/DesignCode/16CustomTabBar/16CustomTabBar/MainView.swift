//
//  MainView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/8.
//

import SwiftUI

struct MainView: View {
    
    @FetchRequest(entity: MemoryItem.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \MemoryItem.kindofMindNum, ascending: false)])
    
    var memoryItems: FetchedResults<MemoryItem>
    
    @State private var newItemName: String = ""
    
    @State private var newItemKindofMemory: KindofMind = .normal
    
    @State private var showNewEntryView = false
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text(getCurrentDate())
                        .padding(.horizontal, 7)
                        .padding(.vertical, 2)
                        .foregroundColor(.secondary)
                        .overlay(
                            RoundedRectangle(cornerRadius: 15)
                                .stroke(.secondary, lineWidth: 2)
                        )
                }
                .offset(y: -4)
                
                ScrollView {
                    ForEach(memoryItems) { memoryItem in
                        MemoryRow()
                    }
                }
            }
            Spacer()
            Button(action: {
                self.showNewEntryView = true
            }) {
                MagicWheel()
            }
            
            
            if showNewEntryView {
                BlankView(bgColor: .black)
                    .opacity(0.5)
                    .onTapGesture {
                        self.showNewEntryView = false
                    }
//
//                entryEditView()
//                    .transition(.move(edge: .bottom))
//                // 'animation' was deprecated in iOS 15.0: Use withAnimation or animation(_:value:) instead.
//                    .animation(.interpolatingSpring(stiffness: 399.0, damping: 35.0, initialVelocity: 5.0))
////                    .withAnimation(.spring())
            }
        }
        
    }
    
    
    func getCurrentDate() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy.MM.dd"
        return dateformatter.string(from: Date())
    }
    
    
    struct MemoryRow: View {
        
        @Environment(\.managedObjectContext) var context
        
        var body: some View {
            
            VStack {
                VStack(alignment: .leading, spacing: 8.0) {
                    //                Spacer()
                    ZStack {
                        Text(getCurrentTime())
                            .font(.system(size: 14))
                            .fontWeight(.regular)
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 5)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(.secondary, lineWidth: 1)
                            )
                    }
                    
                    //                    Text("Build a test app for learning and words following won't be sensible for I just want to test the multiline view. Just want to test the line limit of this style")
                    Text("实际上中文也是需要测试一下的, 因为中国区用户也是必须认真对待的一批客户啊姜丹阿莱. 你想啊 ajar;龙蛋发啦;囧丁;凌如果中国区的用户都不满足阿里反垃圾扥")
                        .font(.footnote)
                        .multilineTextAlignment(.leading)
                        .lineLimit(3)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .foregroundColor(.primary)
                }
                //                .padding(.all, 14.0)
                .padding(.vertical, 2)
                .padding(.horizontal, 19)
                .frame(height: 100.0)
                .background(Color.red.opacity(0.8))
                .cornerRadius(30.0)
                .shadow(color: Color.red.opacity(0.4), radius: 10, x: -10, y: 10)
                .padding(.horizontal, 20)}
            
            //            Circle()
            //                .fill(Color.blue)
            //                .frame(width: 199, height: 199, alignment: .center)
            //            Circle()
            //                .stroke(Color(.white), lineWidth: 80)
            //                .opacity(0.9)
            //                .frame(width: 90, height: 90, alignment: .center)
            //            .shadow(color: .white, radius: 30, x: 0, y: 0)
            

    }
        private func color(for kindofMind: KindofMind) -> Color {
            switch kindofMind {
            case .angry: return .red.opacity(0.8)
            case .disgusting: return .green.opacity(0.8)
            case .fearful: return .green.opacity(0.8)
            case .happy: return .orange.opacity(0.8)
            case .sad: return .blue.opacity(0.8)
            case .normal: return .gray.opacity(0.8)
            }
    }
        
        func getCurrentTime() -> String {
            let dateformatter = DateFormatter()
            dateformatter.dateFormat = "HH:mm:ss"
            return dateformatter.string(from: Date())
        }

    }
    
    struct NoDataView: View {
        var body: some View {
            Image(systemName: "person.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 60, height: 60)
        }
    }
    
    struct BlankView : View {
        var bgColor: Color
        
        var body: some View {
            VStack {
                Spacer()
            }
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
            .background(bgColor)
            .edgesIgnoringSafeArea(.all)
        }
    }
    
    struct MainView_Previews: PreviewProvider {
        static var previews: some View {
            MainView()
                .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
        }
    }
}
