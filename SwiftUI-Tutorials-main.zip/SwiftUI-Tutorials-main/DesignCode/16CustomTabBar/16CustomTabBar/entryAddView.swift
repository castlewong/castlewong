//
//  entryEditView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/1.
//

import SwiftUI


struct entryAddView: View {
    
    
    @Environment(\.managedObjectContext) var context
    
    @ObservedObject var memoryItem: MemoryItem

    @Binding var showNewEntryView: Bool

    @State var writeTime: String
    @State var title: String
    @State var content: String
    @State var kindofMind: KindofMind
    @State var isEditing = false
    
    var body: some View {
        VStack {
            Spacer()
                .frame(height: 10.0)
            NavigationView {
                VStack {
                    titleView()
                    contentView()
                }
                    .navigationBarTitle("Add note",
                                     displayMode: .inline)
                    .navigationBarItems(leading: closeBtnView(), trailing: saveBtnView())
            }
            .cornerRadius(25.0)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
    
    func titleView() -> some View {
        
        TextField("Plz input title", text: $title, onEditingChanged: { editingChanged in
            self.isEditing = editingChanged
        })
        .padding()
        .CardLikeViewofInputView()
    }
    
    func contentView() -> some View {
        VStack {
            ZStack(alignment: .topLeading) {
                TextEditor(text: $content)
                    .font(.body)
                    .foregroundColor(.black)
                    .padding()
                    .lineSpacing(8)

                if content.isEmpty {
                    Text("Plz input content fontPlz input contentbodyfontPlz input contentbody")
                        .foregroundColor(Color(UIColor.placeholderText))
                        .padding(20)

                        .font(.custom("HelveticaNeue", size: 20))
                        .lineSpacing(7)
                }
            }
            
        }
    }
    
    func closeBtnView() -> some View {
        Button(action: {
            self.showNewEntryView = false
        }) {
            Image(systemName: "xmark.circle.fill")
                .font(.system(size: 18))
                .foregroundColor(.secondary)
        }
    }

    func saveBtnView() -> some View {
        Button(action: {
            addMemory(writeTime: "", title: "", content: "", kindofMind: .normal)
            self.showNewEntryView = false
        }) {
            Image(systemName: "square.and.arrow.down.fill")
                .font(.system(size: 18))
                .foregroundColor(.secondary)
            
        }
        .onReceive(memoryItem.objectWillChange, perform: {
            
            
        })
    }
    
    private func addMemory(writeTime: String, title: String, content: String, kindofMind: KindofMind) {
        
        let memory = MemoryItem(context: context)
                memory.writeTime = writeTime
                memory.title = title
                memory.content = content
                memory.kindofMind = kindofMind
        do {
            try context.save()
        } catch {
            print(error)
        }
    }
    
    // MARK: 获取当前系统时间

    func getCurrentTime() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm:ss"
        return dateformatter.string(from: Date())
    }
}

//struct entryEditView_Previews: PreviewProvider {
//    static var previews: some View {
//        entryEditView()
//            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
//    }
//}

// title: "", content: "", showNewEntryView: .constant(true)


//        (memoryItem: $MemoryItem, showNewEntryView: .constant(true), writeTime: "", title: "", content: "", kindofMind: .normal)
