//
//  ContentView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/10/31.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView {
            VStack {

                Spacer()
                Image(systemName: "plus.circle.fill")
                    .font(.largeTitle)
            }
        }
    }
        
    }
    
    
    

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
