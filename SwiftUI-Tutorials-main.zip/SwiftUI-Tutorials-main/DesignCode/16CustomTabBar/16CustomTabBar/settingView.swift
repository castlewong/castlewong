//
//  settingView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/10.
//

import SwiftUI

struct settingView: View {
    var body: some View {
        ZStack {
            diffKindsofMindsView()
            Image(systemName: "person")
                .font(.largeTitle)
        }
        
    }
}

struct settingView_Previews: PreviewProvider {
    static var previews: some View {
        settingView()
    }
}
