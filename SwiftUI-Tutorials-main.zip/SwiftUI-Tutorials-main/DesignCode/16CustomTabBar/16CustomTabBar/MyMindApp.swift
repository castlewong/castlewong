//
//  MyMindApp.swift
//
//  Created by Castle Wong on 2022/10/31.
//

import SwiftUI

@main
struct MyMindApp: App {
    
    @StateObject var viewModel: ViewModel = ViewModel()
    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            MainView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
