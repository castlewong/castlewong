//
//  ViewModifier.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/3.
//

import SwiftUI

struct cardLikeView: ViewModifier {
    func body(content: Content) -> some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                content
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
                content
                    .font(.footnote)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .foregroundColor(.primary)
            }
    //            .padding(.all, 14.0)
            .padding(.horizontal, 12)
            .padding(.vertical, 2)
            .frame(height: 120.0)
            .background(Color.gray.opacity(0.28))
            //        .background(.ultraThinMaterial) 4 02 39
            .cornerRadius(28.0)
            .shadow(color: Color.black.opacity(0.28), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
        
//        content
//            .font(.system(size: 17))
//            .foregroundColor(.white)
//            .padding()
//            .background(Color.teal)
    }
}

extension View {
    func CardLikeView() -> some View {
        self.modifier(cardLikeView())
    }
}

//
//struct ViewModifier_Previews: PreviewProvider {
//    static var previews: some View {
//        ViewModifier()
//    }
//}


struct cardLikeViewofInputView_Normal: ViewModifier {
    func body(content: Content) -> some View {
        VStack {
            VStack(alignment: .leading, spacing: 8.0) {
                //                Spacer()
                content
                    .font(.system(size: 18))
                    .fontWeight(.semibold)
                
                //                Text("20 sections - 3 hours".uppercased())
                //                    .font(.footnote)
                //                    .fontWeight(.semibold)
                //                    .foregroundColor(.secondary)
//                content
//                    .font(.footnote)
//                    .multilineTextAlignment(.leading)
//                    .lineLimit(2)
//                    .frame(maxWidth: .infinity, alignment: .leading)
//                    .foregroundColor(.primary)
            }
    //            .padding(.all, 14.0)
            .padding(.horizontal, 2)
            .frame(height: 48.0)
            .strokeStyle()
            
//            .background(Color.gray.opacity(0.28))
            //        .background(.ultraThinMaterial) 4 02 39
            .shadow(color: Color.black.opacity(0.28), radius: 10, x: -10, y: 10)
            .padding(.horizontal, 20)
        }
        
//        content
//            .font(.system(size: 17))
//            .foregroundColor(.white)
//            .padding()
//            .background(Color.teal)
    }
}

extension View {
    func CardLikeViewofInputView() -> some View {
        self.modifier(cardLikeViewofInputView_Normal())
    }
}
