//
//  dailyNoteView.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/3.
//

import SwiftUI

struct dailyNote: View {

    @State var sentenceText: String = "外表干净是尊重别人，内心干净是尊重自己，言行干净是尊重灵魂。"

    private var models = [
        "将自身所学回馈社会，不也是一件幸福的事么。",
        "当你作为演讲者时，你要装作自己是最了不起的一个人。而当你作为倾听者时，也请一定要装作自己什么也不懂。",
        "当需要你提出建议时，就应该要畅所欲言，不要将想法锁在自己脑子里。",
"一个人若没有深厚的知识积累，就无法轻易说出自己到底喜欢什么。",
"通过沉浸思考，不断积累，就能逐步踏实地将一些知识转变为自己的东西。",
"外表干净是尊重别人，内心干净是尊重自己，言行干净是尊重灵魂。",
        "人的精神思想方面的优势越大，给无聊留下的空间就越小。",
    ]

    var body: some View {
        ZStack {
            Color(.white)
                .edgesIgnoringSafeArea(.all)
            VStack {
                titleView()
                Spacer()
                sentenceView()
                Spacer()
                refreshBtn()
                Text("test")
                    .CardLikeView()
            }.padding()
        }
    }

    // 标题
    func titleView() -> some View {
        HStack {
            Text("Daily Dose of Spirit")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.teal)
            Spacer()
        }
    }

    // 句子展示
    func sentenceView() -> some View {
        Text(sentenceText)
            .font(.system(size: 30))
            .padding()
            .foregroundColor(Color(.systemBlue))
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: 250)
            .background(.teal)
            .cornerRadius(8)
    }

    // 刷新按钮
    func refreshBtn() -> some View {
        Image(systemName: "repeat.circle.fill")
            .font(.system(size: 52))
            .foregroundColor(.teal)
            .padding()
            .onTapGesture {
                getRandomSentence()
            }
    }

    // 随机展示句子
    func getRandomSentence() {
        let index = Int(arc4random() % UInt32(models.count))
        sentenceText = models[index]
    }
}


struct dailyNote_Previews: PreviewProvider {
    static var previews: some View {
        dailyNote()
    }
}
