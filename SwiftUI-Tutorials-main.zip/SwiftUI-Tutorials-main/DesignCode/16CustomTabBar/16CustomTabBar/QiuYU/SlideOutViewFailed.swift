//
//  SlideOutMenu.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/4.
//

import SwiftUI

struct SlideOutViewFailed: View {
    
    private var moreBtnView: some View {
        Button(action: {
            withAnimation {
                offsetX = 0
            }
        }) {
            Image(systemName: "list.bullet")
                .foregroundColor(.black)
        }
    }
    
    @State var menuWidth = UIScreen.main.bounds.width - 60
    @State var offsetX = -UIScreen.main.bounds.width + 60
    
    var body: some View {
        NavigationView {
            Text("Click the UpLeft to Slide Out")
                .padding()
                .navigationBarTitle("Main Board", displayMode: .inline)
                .navigationBarItems(leading: moreBtnView)
        }
//        SlideOutMenu1(menuWidth: $menuWidth, offsetX: $offsetX)
        la(menuWidth: $menuWidth, offsetX: $offsetX)
    }
    

}

struct listItemView: View {
    var itemImage: String
    var itemName: String
    var body: some View {
        Button(action: {
            
        }) {
            HStack {
                Image(systemName: itemImage)
                    .font(.system(size: 17))
                    .foregroundColor(.black)
                Text(itemName)
                    .foregroundColor(.black)
                    .font(.system(size: 17))
                Spacer()
                Image(systemName: "chevron.forward")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
            }.padding(.vertical, 10)
        }
    }
}


struct la: View {
    @Binding var menuWidth: CGFloat
    @Binding var offsetX: CGFloat
    
    var body: some View {
        Form {
            Section {
                listItemView(itemImage: "lock", itemName: "Binding")
                listItemView(itemImage: "gear.circle", itemName: "Gen")
            }
            Section {
                listItemView(itemImage: "lock", itemName: "Binding")
                listItemView(itemImage: "gear.circle", itemName: "Gen")
            }
        }
        .padding(.trailing, UIScreen.main.bounds.width - menuWidth)
        .edgesIgnoringSafeArea(.all)
        .shadow(color: Color.black.opacity(offsetX != 0 ? 0.1 : 0), radius: 5, x: 5, y: 0)
        .offset(x: offsetX)
        .background(
            Color.black.opacity(offsetX == 0 ? 0.5 : 0)
                .ignoresSafeArea(.all, edges: .vertical)
                .onTapGesture {
                    withAnimation{
                        offsetX = -menuWidth
                    }
                })
    }
}


struct test_Previews: PreviewProvider {
    static var previews: some View {
        SlideOutViewFailed()
    }
}
