//
//  Model.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/13.
//

//import Foundation
//import SwiftUI
//
//struct MemoryModel: Identifiable, Codable {
//    var id: UUID()
//    var writeTime: String
//}
