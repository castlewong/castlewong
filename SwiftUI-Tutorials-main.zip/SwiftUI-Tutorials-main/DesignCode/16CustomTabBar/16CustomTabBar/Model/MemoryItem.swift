//
//  Model.swift
//  16CustomTabBar
//
//  Created by Castle on 2022/11/8.
//

import Foundation
import SwiftUI
import CoreData


enum KindofMind: Int {
    case normal = 0
    case angry = 1
    case happy = 2
    case fearful = 3
    case disgusting = 4
    case sad = 5
}

// class and struct
public class MemoryItem: NSManagedObject {
    @NSManaged public var id: UUID
    @NSManaged public var writeTime: String
    @NSManaged public var title: String
    @NSManaged public var content: String
    @NSManaged public var kindofMindNum: Int32
    // properties are marked with @Published so that the subscribers are informed whenever there are any changes of the values
}

    extension MemoryItem: Identifiable {
        
        var kindofMind: KindofMind {
            get {
                return KindofMind(rawValue: Int(kindofMindNum)) ?? .normal
            }
            
            set {
                self.kindofMindNum = Int32(newValue.rawValue)
            }
        }
    }


