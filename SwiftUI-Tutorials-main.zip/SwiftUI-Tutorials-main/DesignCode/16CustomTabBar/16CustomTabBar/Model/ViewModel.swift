//
//  ViewModel.swift
//  16CustomTabBar
//
//  Created by 陈安冉 on 2022/11/13.
//
// model声明数据模型参数 View构建页面和基础交互 viewmodel用来实现基础功能 CRUD 在viewmodel中实现 再在View中调用 做到页面和数据分开
// 👇🏻 把所有页面用到的参数抽离出来 保持代码清晰

import Foundation
import SwiftUI
import Combine

class ViewModel: ObservableObject {

    @Published var memoryModels = [MemoryItem]()

    // already in MemoryItem
//    @Published var writeTime: String = ""
//    @Published var title: String = ""
//    @Published var content: String = ""
@Published var searchText = ""
    @Published var isSearching: Bool = false
    @Published var isAdd: Bool = true
    @Published var showNewEntryView: Bool = false
    @Published var showEditNoteView: Bool = false
    
    @Published var showActionSheet: Bool = false
    @Published var showToastMessage: String = "Notice you sth."

    func getCurrentTime() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm:ss"
        return dateformatter.string(from: Date())
    }
    
//    func addMemory(writeTime: String, title: String, content: String, kindofMind: Int) {
//        
//        let memory = MemoryItem(writeTime: getCurrentTime(), title: getCurrentTime(), content: content, kindofMind: KindofMind.normal)
//        memoryModels.append(memory)
//    }
//
    
    func editItem(item: MemoryItem) {
        if let id = memoryModels.firstIndex(where: { $0.id == item.id }) {
            memoryModels[id] = item
//            addMemory(writeTime: getCurrentTime(), title: getCurrentTime(), content: content, kindofMind: KindofMind.normal)
        }
    }
}
