//
//  NewTask.swift
//  Task Manager Core Data
//
//  Created by KIOXIA on 2022/12/2.
//

import SwiftUI

struct NewTask: View {
    @Environment(\.dismiss) var dismiss
    
    // MARK: task value
    @State var taskTitle: String = ""
    @State var taskDescription: String = ""
    @State var taskDate: Date = Date()
    
    // MARK: Core data context
    @Environment(\.managedObjectContext) var context
    
    @EnvironmentObject var taskModel: TaskViewModel
    var body: some View {

        NavigationView{
            
            List{
                
                Section {
                    TextField("Go to work", text: $taskTitle)
                } header: {
                    Text("Text Title")
                }
                
                Section {
                    TextField("Nothing", text: $taskDescription)
                } header: {
                    Text("Task Description")
                }
                
// Disabling date for edit mode
                if taskModel.editTask == nil{
                    Section {
                        DatePicker("", selection: $taskDate)
                            .datePickerStyle(.graphical)
                            .labelsHidden()
                    } header: {
                        Text("Text Date")
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Add new task")
            .navigationBarTitleDisplayMode(.inline)
            // MARK: disbaling dismiss on swipe
            .interactiveDismissDisabled()
            // MARK: action btns
            .toolbar {
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save"){
                        // simple create a new entity object with context and set the values for the object and finally save the context, this will create a new object in our core data
                        if let task = taskModel.editTask{
                            task.taskTitle = taskTitle
                            task.taskDescription = taskDescription
                        } else {
                            let task = Task(context: context)
                            task.taskTitle = taskTitle
                            task.taskDescription = taskDescription
                            task.taskDate = taskDate
                        }
                        
                        // saving
                        try? context.save()
                        // Dismissing view
                        dismiss()
                    }
                    .disabled(taskTitle == "" || taskDescription == "")
                }
                
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel"){
                        dismiss()
                    }
                }
            }
            // loading task data if from edit
            .onAppear {
                if let task = taskModel.editTask{
                    taskTitle = task.taskTitle ?? ""
                    taskDescription = task.taskDescription ?? ""
                }
            }
        }
    }
}


