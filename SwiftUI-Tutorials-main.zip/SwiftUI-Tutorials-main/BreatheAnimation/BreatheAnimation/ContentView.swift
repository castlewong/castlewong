//
//  ContentView.swift
//  BreatheAnimation
//
//  Created by 陈安冉 on 2022/10/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
