//
//  Home.swift
//  BreatheAnimation
//
//  Created by 陈安冉 on 2022/10/26.
//

import SwiftUI


struct Home: View {
    // view properties
    @State var currentType: BreatheType = sampleTypes[0]
    @Namespace var animation
    @State var showBreathedView: Bool = false
    @State var startAnimation: Bool = false
    @State var timerCount: CGFloat = 0
    @State var breatheAction: String = "Breathe In"
    @State var count: Int = 0
    
    var body: some View {
        ZStack{
            Background()
            
            Content()
        }
        // MARK: Timer
        .onReceive(Timer.publish(every: 0.01, on: .main, in: .common).autoconnect()) { _ in
            if showBreathedView {
                if timerCount > 3.2 {
                    timerCount = 0
                    breatheAction =
                    // MARK: 10:42
                } else {
                    
                }
            }
        }
    }
    
// MARK: Main Content
    @ViewBuilder
    func Content() -> some View {
        VStack {
            HStack {
                Text("Breathe")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Button {
                        
                    } label: {
                        Image(systemName: "suit.heart")
                            .font(.title2)
                            .foregroundColor(.white)
                            .frame(width: 42, height: 42)
                            .background {
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .fill(.ultraThinMaterial)
                            }
                    }
            }
            .padding()
            .opacity(showBreathedView ? 0 : 1)
            
            GeometryReader { proxy in
                let size = proxy.size
                
                VStack {
                    BreatheView(size: size)
                    
                    // MARK: View properties
                    Text("Breathe to reduce")
                        .font(.title3)
                        .foregroundColor(.white)
                        .opacity(showBreathedView ? 0 : 1)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(sampleTypes) { type in
                                Text(type.title)
                                    .foregroundColor(currentType.id == type.id ? .black : .white)
                                    .padding(.vertical, 10)
                                    .padding(.horizontal, 15)
                                    .background {
                                        // MARK: matched geometryeffect
                                        ZStack {
                                            if currentType.id == type.id {
                                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                    .fill(.white)
                                                    .matchedGeometryEffect(id: "TAB", in: animation)
                                            } else {
                                                RoundedRectangle(cornerSize: 10, style: .continuous)
                                                    .stroke(.white.opacity(0.5))
                                            }
                                        }
                                    }
                                    .contentShape(Rectangle())
                                    .onTapGesture {
                                        withAnimation(.easeInOut) {
                                            currentType = type
                                        }
                                    }
                            }
                        }
                        .padding()
                        .padding(.leading, 25)
                    }
                    .opacity(showBreathedView ? 0 : 1)
                    
                    Button(action: startBreathing){
                        Text(showBreathedView ? "Finish Breathe" : "START")
                            .fontWeight(.semibold)
                            .foregroundColor(showBreathedView ? .white.opacity(0.75) : .black)
                            .padding(.vertical, 15)
                            .frame(maxWidth: .infinity)
                            .background {
                                if showBreathedView {
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(.white.opacity(0.5))
                                } else {
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .fill(currentType.color.gradient)
                            }
                        }
                    }
                    .padding()
                }
                .frame(width: size.width, height: size.height, alignment: .bottom)
            }
        }
        .frame(maxHeight: .infinity, alignment: .top)
    }
    
// MARK: Breathe Animated Circles
    @ViewBuilder
    func BreatheView(size: CGSize) -> some View {
        // use 8 circels it's your wish 360 /8 = 45 deg for each
        ZStack {
            ForEach(1...8, id: \.self) { index in
                Circle()
                    .fill(Color.green.gradient.opacity(0.6))
//                    .fill(currentType.color.gradient.opacity(0.5))
                    .frame(width: 150, height: 150)
//                // 150 / 2 -> 7
                    .offset(x: startAnimation ? 0 : 75)
                    .rotationEffect(.init(degrees: Double(index) * 45))
                    .rotationEffect(.init(degrees: startAnimation ? -45 : 0))

            }
        }
        .frame(height: (size.width - 40))
    }
    
    
    
    
//    bg image with gradient overlays
    @ViewBuilder
    func Background() -> some View {
        GeometryReader{proxy in
            let size = proxy.size
            Image("BG1")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .offset(y: -50)
                .frame(width: size.width, height: size.height)
                .clipped()
                .overlay {
                    ZStack {
                        Rectangle()
                            .fill(.linearGradient(colors: [
                                currentType.color.opacity(0.9),
                                .clear,
                                .clear
                            ], startPoint: .top, endPoint: .bottom))
                            .frame(height: size.height / 1.5)
                            .frame(maxHeight: .infinity, alignment: .top)
                        
                        Rectangle()
                            .fill(.linearGradient(colors: [
                                .clear,
                                .red,
                                .red,
                                .red
                            ], startPoint: .top, endPoint: .bottom))
                            .frame(height: size.height / 1.35)
                            .frame(maxHeight: .infinity, alignment: .bottom)
                    }
                    }
                }
                .ignoresSafeArea()
    }
    
    // MARK: breathing action
    func startBreathing() {
        withAnimation(.interactiveSpring(response: 0.6, dampingFraction: 0.7, blendDuration: 0.7)) {
            showBreathedView.toggle()
        }
        
        if showBreathedView {
            // MARK: Breathe View Animation
            // since we havemax 3 secs of breathe
            withAnimation(.easeInOut(duration: 3).delay(0.05)) {
                startAnimation = true
            }
        } else {
            
        }
    }
}


struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}

