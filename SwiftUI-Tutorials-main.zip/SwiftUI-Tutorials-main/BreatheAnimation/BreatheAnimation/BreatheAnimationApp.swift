//
//  BreatheAnimationApp.swift
//  BreatheAnimation
//
//  Created by 陈安冉 on 2022/10/26.
//

import SwiftUI

@main
struct BreatheAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
