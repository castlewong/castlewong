//
//  ContentView.swift
//  Sawmate
//
//  Created by 陈安冉 on 2022/10/14.
//

import SwiftUI
import AVFoundation


struct ContentView: View {
    
    @State var isDark = false
    var body: some View {
        
        NavigationView {
            
            Home(isDark: $isDark)
                .navigationBarHidden(true)
                .preferredColorScheme(isDark ? .dark : .light)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home: View {

    @Binding var isDark : Bool
    var width: Double = UIScreen.main.bounds.width
    @State var current_Time = Time(min: 0, sec: 0, hour: 0)
    @State var receiver = Timer.publish(every: 1, on: .current, in: .default).autoconnect()
    
    var body: some View{
        
//        ZStack {
//            Color(red: 13.0 / 255.0, green: 16.0 / 255.0, blue: 35.0 / 255.0).edgesIgnoringSafeArea(.all)
                
                

            VStack {

                HStack {
                    Text("I Love Audrey.")
                        .font(.title)
                        .fontWeight(.heavy)
                        .foregroundColor(.orange.opacity(0.7))
                        
                    Spacer(minLength: 0)
                    
                    Button(action: {isDark.toggle()}) {
                        
                        Image(systemName: isDark ? "moon.fill" : "sun.max.fill")
                            .foregroundColor(isDark ? .black : .white)
                            .padding()
                            .background(Color.orange.opacity(0.7))
                            .clipShape(Circle())
                            .shadow(radius: 4)
                            
                                .onTapGesture {
                                    Haptics.hapticSuccess()
                                    isDark.toggle()
                                    AudioServicesPlaySystemSound(1105)
                                }
                    }
                }
                .padding()
                
                Spacer(minLength: 0)
                
                
                ZStack{
                    
                    Circle()
                        .fill(Color(.orange).opacity(0.2))
                    
                    
                    
                    // draw秒针和分针
                    
                    ForEach(0..<60, id: \.self) { i in
                        
                        Rectangle()
                            .frame(width: 4, height: (i % 5) == 0 ? 22 : 10) // hands' shape
                            .offset(y: (width - 110) / 2)
                            .rotationEffect(.init(degrees: Double(i) * 6))
                            .foregroundColor(.orange).opacity(0.9)
                    }
                    
                    // hour
                    Rectangle()
                        .fill(Color.yellow)
                        .frame(width: 8, height: (width - 260) / 2)
                        .offset(y: -(width - 240) / 4 )
                        .rotationEffect(.init(degrees: Double(current_Time.hour + (current_Time.min / 60)) * 30))
                    


                    // min
                    Rectangle()
                        .fill(Color.orange)
                        .frame(width: 4.5, height: (width - 160) / 2)
                        .offset(y: -(width - 200) / 4 )
                        .rotationEffect(.init(degrees: Double(current_Time.min) * 6))
                    // sec
                    Rectangle()
                        .fill(Color.red)
                        .frame(width: 4, height: (width - 65) / 2)
                        .offset(y: -(width - 100) / 4 )
                        .rotationEffect(.init(degrees: Double(current_Time.sec) * 6))
    //                    .animation(.spring())
                    
                    // center
                    ZStack {
                        Circle()
                            .fill(Color.orange)
                        .frame(width: 15, height: 15)
                        Circle()
                            .fill(Color.yellow)
                            .frame(width: 10, height: 10)
                        Circle()
                            .fill(Color.red)
                            .frame(width: 5, height: 5)

                    }
                    
                    
                }
                .frame(width: width - 80, height: width - 80)
                
                // 获取时区
                Text(Locale.current.localizedString(forRegionCode:
                    Locale.current.regionCode!) ?? "")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .padding(.top,35)
                    .foregroundColor(.gray).opacity(0.7)
                
                Text(getTime())
                    .font(.system(size: 108))
                    .fontWeight(.heavy)
                    .padding(.top,1)
                    .foregroundColor(.secondary)
                
                Spacer(minLength: 0)
            }
            
            .onAppear(perform: {
                let calender = Calendar.current
                
                let min = calender.component(.minute, from: Date())
                let sec = calender.component(.second, from: Date())
                let hour = calender.component(.hour, from: Date())
                
                withAnimation(Animation.linear(duration: 0.01)){
                    
                    self.current_Time = Time(min: min, sec: sec, hour: hour)
                }
            })
            .onReceive(receiver) { (_) in
                let calender = Calendar.current
                
                let min = calender.component(.minute, from: Date())
                let sec = calender.component(.second, from: Date())
                let hour = calender.component(.hour, from: Date())
                
                withAnimation(Animation.linear(duration: 0.01)){
                    
                    self.current_Time = Time(min: min, sec: sec, hour: hour)
                }
        }
        }
    }
    
    func getTime()->String{
        
        let format = DateFormatter()
        format.dateFormat = "hh:mm"
        
        return format.string(from: Date())
    }


// calculating time
struct Time {
    var min : Int
    var sec : Int
    var hour : Int
}

// haptics feedback
struct Haptics {
    static func hapticSuccess() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }
    static func hapticWarning() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.warning)
    }
}
