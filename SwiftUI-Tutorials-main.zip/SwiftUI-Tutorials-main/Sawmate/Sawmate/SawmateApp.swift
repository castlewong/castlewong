//
//  SawmateApp.swift
//  Sawmate
//
//  Created by 陈安冉 on 2022/10/14.
//

import SwiftUI

@main
struct SawmateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
