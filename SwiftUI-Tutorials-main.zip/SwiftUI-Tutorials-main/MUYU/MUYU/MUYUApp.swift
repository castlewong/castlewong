//
//  MUYUApp.swift
//  MUYU
//
//  Created by Castle on 2022/10/26.
//

import SwiftUI

@main
struct MUYUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
