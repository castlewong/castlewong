//
//  ContentView.swift
//  MUYU
//
//  Created by Castle on 2022/10/26.
//

import SwiftUI

struct ContentView: View {
    let colors: [Color] = [.blue, .orange, .yellow, .teal, .pink]
    // Cannot assign to property: 'self' is immutable
    @State var selectedColor = Color.blue
    @State var touchCount = 0
    
    var body: some View {
                
        VStack {

            Text("MUYU")
                .font(.system(.largeTitle, design: .serif))
            Text("You have some GD")
                .font(.footnote)
                .foregroundColor(.gray)
            Divider()
            Spacer()
            
            if touchCount % 2 == 0 {
                if touchCount != 0 {
                    Text("Gond De + 2")
                }
            }
            
            
            Button {
                changeColor()
            } label: {
                Image(systemName: "fish.fill")
                    .resizable()
                    .frame(width: 200, height: 200)
                    .foregroundColor(selectedColor)
            }
            Spacer()
        }
    }
    
    func changeColor() {
        selectedColor = colors.randomElement() ?? Color.orange
        touchCount += 1
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
