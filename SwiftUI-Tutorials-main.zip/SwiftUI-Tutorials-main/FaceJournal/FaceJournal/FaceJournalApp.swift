//
//  FaceJournalApp.swift
//  FaceJournal
//
//  Created by 陈安冉 on 2022/10/19.
//

import SwiftUI

@main
struct FaceJournalApp: App {
    
    @StateObject var viewModel: ViewModel = ViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
