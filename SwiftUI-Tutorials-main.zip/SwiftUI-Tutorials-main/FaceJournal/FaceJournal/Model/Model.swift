//
//  Model.swift
//  FaceJournal
//
//  Created by 陈安冉 on 2022/10/19.
//
import Foundation
import SwiftUI

struct NoteModel: Identifiable, Codable {
    var id = UUID()
    var writeTime: String
    var title: String
    var content: String
}


//import Foundation
//// 类NoteItem 可被观察 识别 遵循这两项协议
//// 在ObservableObject协议中需要使用@Published定义 这样才能在参数改变的时候检测到变化
//// 由于使用Identifiable可被识别协议 因此需要声明一个id为UUID()
//class NoteItem: ObservableObject, Identifiable {
//    var id = UUID()
//    @Published var writeTime: String = ""
//    @Published var title: String = ""
//    @Published var content: String = ""
//
//    // 实例化
//    init(writeTime: String, title: String, content: String) {
//        self.writeTime = writeTime
//        self.title = title
//        self.content = content
//    }
//}
