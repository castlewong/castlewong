//
//  ViewModel.swift
//  FaceJournal
//
//  Created by 陈安冉 on 2022/10/22.
//

import Foundation
import Combine
import SwiftUI

class ViewModel: ObservableObject {
    
    // data model
    @Published var noteModels = [NoteModel]()
    
    @Published var writeTime: String = ""
    @Published var title: String = ""
    @Published var content: String = ""
    @Published var searchText: String = ""
    
    @Published var isSearching: Bool = false
    
    @Published var isAdd: Bool = true
    
    @Published var showNewNoteView: Bool = false
    
    @Published var showEditNoteView: Bool = false
    
    @Published var showActionSheet: Bool = false
    
    @Published var showToast = false
    
    @Published var showToastMessage: String = "Notice Message"

    //初始化
    init() {
        loadItems()
        saveItems()
    }

    // 获取设备上的文档目录路径
    func documentsDirectory() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    // 获取plist数据文件的路径
    func dataFilePath() -> URL {
        documentsDirectory().appendingPathComponent("IdeaNote.plist")
    }

    // 将数据写入本地存储
    func saveItems() {
        let encoder = PropertyListEncoder()
        do {
            let data = try encoder.encode(noteModels)
            try data.write(to: dataFilePath(), options: Data.WritingOptions.atomic)
        } catch {
            print("Error writing items to file: (error.localizedDescription)")
        }
    }

    // 从本地存储加载数据
    func loadItems() {
        let path = dataFilePath()

        if let data = try? Data(contentsOf: path) {
            let decoder = PropertyListDecoder()
            do {
                noteModels = try decoder.decode([NoteModel].self, from: data)
            } catch {
                print("Error reading items: (error.localizedDescription)")
            }
        }
    }
    
    // 创建笔记
     func addItem(writeTime: String, title: String, content: String) {
         let newItem = NoteModel(writeTime: writeTime, title: title, content: content)
         noteModels.append(newItem)
         saveItems()
     }
     
     // 获得数据项ID
     func getItemById(itemId: UUID) -> NoteModel? {
         return noteModels.first(where: { $0.id == itemId }) ?? nil
     }

     // 删除笔记
     func deleteItem(itemId: UUID) {
         noteModels.removeAll(where: { $0.id == itemId })
         saveItems()
     }

     // 编辑笔记
     func editItem(item: NoteModel) {
         if let id = noteModels.firstIndex(where: { $0.id == item.id }) {
             noteModels[id] = item
             saveItems()
         }
     }
     
     // 搜索笔记
     func searchContet() {
         let query = searchText.lowercased()
         DispatchQueue.global(qos: .background).async {
             let filter = self.noteModels.filter { $0.content.lowercased().contains(query) }
             DispatchQueue.main.async {
                 self.noteModels = filter
             }
         }
     }
    
    // 获取当前系统时间
    func getCurrentTime() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "YYYY.MM.dd  HH:MM:s"
        return dateformatter.string(from: Date())
                    .replacingOccurrences(of: "2", with: "2️⃣")
                    .replacingOccurrences(of: "1", with: "1️⃣")
                    .replacingOccurrences(of: "0", with: "0️⃣")
                    .replacingOccurrences(of: "3", with: "3️⃣")
                    .replacingOccurrences(of: "4", with: "4️⃣")
                    .replacingOccurrences(of: "5", with: "5️⃣")
                    .replacingOccurrences(of: "6", with: "6️⃣")
                    .replacingOccurrences(of: "7", with: "7️⃣")
                    .replacingOccurrences(of: "8", with: "8️⃣")
                    .replacingOccurrences(of: "9", with: "9️⃣")
//                    .replacingOccurrences(of: ".", with: "-")

    }
    
    // 判断文字是否为空
    func isTextEmpty(text:String) -> Bool{
        if text == "" {
            return true
        } else {
            return false
        }
    }

}
