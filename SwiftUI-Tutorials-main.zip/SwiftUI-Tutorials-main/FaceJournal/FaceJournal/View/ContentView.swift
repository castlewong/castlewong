//
//  ContentView.swift
//  FaceJournal
//
//  Created by 陈安冉 on 2022/10/19.
//

import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var viewModel: ViewModel
    
    var body: some View {
        NavigationView {
            ZStack {
                if viewModel.isSearching == false && viewModel.noteModels.count == 0 {
                    noDataView()
                } else {
                    VStack {
                        searchBarView()
                        noteListView()
                    }
                }
                newBtnView()
            }.navigationBarTitle("Face Today.", displayMode: .inline)
        }.sheet(isPresented: $viewModel.showNewNoteView) {
                NewNoteView(noteModel: NoteModel(writeTime: "", title: "", content: ""))
        }
    }
    
    // MARK: 缺省图
    func noDataView() -> some View {
        VStack(alignment: .center, spacing: 20) {
            Image("mainImage")
                .resizable()
                .scaledToFit()
                .frame(width: 240)
            //                .padding(.bottom)
            Text("Face Myself.")
                .font(.system(size: 27))
                .bold()
                .foregroundColor(.gray)
        }
    }
    
    //    MARK: Note list view
    func noteListView() -> some View {
        List {
            ForEach(viewModel.noteModels) { noteItem in
                NoteListRow(itemId: noteItem.id)
            }
        }
        .listStyle(InsetListStyle())
        
    }
    //    struct NoteListView: View {
    //
    //        @EnvironmentObject var viewModel: ViewModel
    //
    //        var itemId: UUID
    //
    //        var item: NoteModel? {
    //            return viewModel.getItemById(itemId: itemId)
    //        }
    //
    //        var body: some View {
    //            List {
    //                ForEach(viewModel.noteModels) { noteItem in
    //                    NoteListRow(itemId: noteItem.id)
    //                }
    //            }
    //            .listStyle(InsetListStyle())
    //        }
    //    }
    
    // MARK: 单条笔记
    
    func searchBarView() -> some View {
            TextField("Search Content", text: $viewModel.searchText)
                .padding(7)
                .padding(.horizontal, 25)
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .overlay(
                    HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        .padding(.leading, 8)
                    // if = "" clear all if not show multiply button
                    
                    // show the clear btn when editing
                    if viewModel.searchText != "" {
                        // button action is for multiply sign bind to that
                        Button(action: {
                            self.viewModel.searchText = ""
                            self.viewModel.loadItems()
                        }) {
                            Image(systemName: "multiply.circle.fill")
                                .foregroundColor(.gray)
                                .padding(.trailing, 8)
                        }
                    }
                }
            )
                .padding(.horizontal, 10)
                .onChange(of: viewModel.searchText) { _ in
                    if viewModel.searchText != "" {
                        self.viewModel.isSearching = true
                        self.viewModel.searchContet()
                    } else {
                        viewModel.searchText = ""
                        self.viewModel.isSearching = false
                        self.viewModel.loadItems()
                    }
                }
        
    }
    
    // MARK: add note button
    func newBtnView() -> some View {
        // use VS and spacer to push the button in the down
        // use HStack and spacer to push it to the right
        // use padding to leave space in the bottom and trailing right
        VStack {
            Spacer()
            HStack {
                Spacer()
                Button(action: {
                    self.viewModel.isAdd = true
                    self.viewModel.writeTime = viewModel.getCurrentTime()
                    self.viewModel.title = ""
                    self.viewModel.content = ""
                    self.viewModel.showNewNoteView = true
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 48))
                        .foregroundColor(.blue)
                }
            }
        }
        .padding(.bottom, 32)
        .padding(.trailing, 32)
    }
}

struct NoteListRow: View {
    
    @EnvironmentObject var viewModel: ViewModel
    
    var itemId: UUID
    
    var item: NoteModel? {
        return viewModel.getItemById(itemId: itemId)
    }
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 10) {
                Text(item?.writeTime ?? "")
                    .font(.system(size: 14))
                    .foregroundColor(.black)
                Text(item?.title ?? "")
                    .font(.system(size:20))
                    .foregroundColor(.black)
                Text(item?.content ?? "")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
            }
            
            .onTapGesture {
                self.viewModel.isAdd = false
                self.viewModel.showEditNoteView = true
            }
            
            Spacer()
            
            Button(action: {
                viewModel.showActionSheet = true
            }) {
                Image(systemName: "ellipsis")
                    .foregroundColor(.gray)
                    .font(.system(size: 23))
            }
            .sheet(isPresented: $viewModel.showEditNoteView) {
                NewNoteView(noteModel: self.item ?? NoteModel(writeTime: "", title: "", content: ""))
            }
        }
    }
        
    
//        .actionSheet(isPresented: self.$viewModel.showActionSheet) {
//            ActionSheet(title: Text("you sure?"), message: nil, buttons: [
//                .destructive(Text("delete"), action: {
//                    self.viewModel.deleteItem(itemId: itemId)
//                }),
//                .cancel(Text("cancel")),
//            ])
//        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(ViewModel())
    }
}
