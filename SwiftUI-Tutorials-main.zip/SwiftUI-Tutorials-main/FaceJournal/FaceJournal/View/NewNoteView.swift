//
//  NewNoteView.swift
//  FaceJournal
//
//  Created by 陈安冉 on 2022/10/20.

//  模态弹窗 以临时出现的形式显示内容 需要明确的操作才能退出
//  主要目的 帮助用户专注于一个独立任务或一组相关选项 确保用户接受到重要信息

import SwiftUI

struct NewNoteView: View {
    
    @EnvironmentObject var viewModel: ViewModel  // check
    @State var noteModel: NoteModel
    @Environment(\.presentationMode) var presentationMode
    
//    @State var isEditing = false
//
//    @State var content: String

    var body: some View {
        NavigationView {
            VStack {
                Divider()
                titleView()
                Divider()
                contentView()
            }
                .navigationBarTitle("Add Note", displayMode: .inline)
                .navigationBarItems(leading: closeBtnView(), trailing: saveBtnView())
//                .toast(present: $viewModel.showToast, message: $viewModel.showToastMessage)
            }
        }
    
    // MARK: close button
    func closeBtnView() -> some View {
        Button(action: {
            self.presentationMode.wrappedValue.dismiss()
        }) {
            Image(systemName: "xmark.circle.fill")
                .font(.system(size: 17))
                .foregroundColor(.gray)
        }
    }
    
    // MARK: save button
    func saveBtnView() -> some View {
        Button(action: {
            if viewModel.isAdd {
                if viewModel.isTextEmpty(text: viewModel.title) {
                    viewModel.showToast = true
                    viewModel.showToastMessage = "input some title mfk!"
                }
                
                
                else if viewModel.isTextEmpty(text: viewModel.content) {
                    viewModel.showToast = true
                    viewModel.showToastMessage = "input some content mfk!"
                }
                
                // 校验通过
                else {
                    // 新增一条笔记
                    self.viewModel.addItem(writeTime: viewModel.getCurrentTime(), title: viewModel.title, content: viewModel.content)
                    // close 弹窗
                    self.presentationMode.wrappedValue.dismiss()
                }
            } else {
                
                // check if title is empty
                if viewModel.isTextEmpty(text: noteModel.title) {
                    viewModel.showToast = true
                    viewModel.showToastMessage = "title cannot be empty"
                }
                
                else if viewModel.isTextEmpty(text: noteModel.content) {
                    viewModel.showToast = true
                    viewModel.showToastMessage = "content cannot be empty"
                }
            }
        }) {
                Text("Complete")
                    .font(.system(size: 17))
        }
    }
    
    // MARK: check if the input is empty
    func isNull(text: String) -> Bool {
        if text == "" {
            return true
        }
        return false
    }
    


 
    
    // MARK: title input frame
    func titleView() -> some View {
        
        TextField("Plz input title", text: viewModel.isAdd ? $viewModel.title : $noteModel.title)
            .padding()
    }
    
    // MARK: content input frame
    func contentView() -> some View {
        ZStack(alignment: .topLeading) {
            TextEditor(text: viewModel.isAdd ? $viewModel.content : $noteModel.content)
                .font(.system(size: 17))
                .padding()
            if viewModel.isAdd ? (viewModel.content.isEmpty) : (noteModel.content.isEmpty) {
                Text("Plz input content")
                    .foregroundColor(Color(UIColor.placeholderText))
                    .padding(20)
            }
        }.padding()
    } // content editor点不动
    
    // MARK: add note func
//    func addNote(writeTime: String, title: String, content: String) {
//        let note = NoteItem(writeTime: writeTime, title: title, content: content)
//        noteItems.append(note)
//    }
    
    // MARK: get current time transfered to ViewModel already
//    func getCurrentTime() -> String {
//        let dateformatter = DateFormatter()
////        dateformatter.dateFormat = "YYYY.MM.dd  HH:MM"
//        dateformatter.dateFormat = "YYYY.MM.dd  HH:MM:ss"
//
//        return dateformatter.string(from: Date())
//            .replacingOccurrences(of: "2", with: "2️⃣")
//            .replacingOccurrences(of: "1", with: "1️⃣")
//            .replacingOccurrences(of: "0", with: "0️⃣")
//            .replacingOccurrences(of: "3", with: "3️⃣")
//            .replacingOccurrences(of: "4", with: "4️⃣")
//            .replacingOccurrences(of: "5", with: "5️⃣")
//            .replacingOccurrences(of: "6", with: "6️⃣")
//            .replacingOccurrences(of: "7", with: "7️⃣")
//            .replacingOccurrences(of: "8", with: "8️⃣")
//            .replacingOccurrences(of: "9", with: "9️⃣")
////            .replacingOccurrences(of: ".", with: "-")
//
//    }
}

struct NewNoteView_Previews: PreviewProvider {
    // 只要使用了@Binding绑定参数 就必须在其他与该页面关联的页面双向绑定
    static var previews: some View {
        NewNoteView(noteModel: NoteModel(writeTime: "", title: "", content: "")).environmentObject(ViewModel())
    }
}
