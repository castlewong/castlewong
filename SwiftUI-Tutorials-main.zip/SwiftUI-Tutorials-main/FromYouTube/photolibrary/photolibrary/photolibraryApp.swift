//
//  photolibraryApp.swift
//  photolibrary
//
//  Created by KIOXIA on 2022/12/27.
//

import SwiftUI

@main
struct photolibraryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
