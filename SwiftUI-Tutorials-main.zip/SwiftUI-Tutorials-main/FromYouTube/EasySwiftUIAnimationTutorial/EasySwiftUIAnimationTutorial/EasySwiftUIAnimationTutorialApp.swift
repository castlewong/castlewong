//
//  EasySwiftUIAnimationTutorialApp.swift
//  EasySwiftUIAnimationTutorial
//
//  Created by 陈安冉 on 2022/11/11.
//

import SwiftUI

@main
struct EasySwiftUIAnimationTutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
