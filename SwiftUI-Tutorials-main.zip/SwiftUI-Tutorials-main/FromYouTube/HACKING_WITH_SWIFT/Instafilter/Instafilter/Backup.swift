//
//  Backup.swift
//  Instafilter
//
//  Created by 陈安冉 on 2023/1/1.
//

//struct ContentView: View {
//    @State private var image: Image?
//    @State private var inputImage: UIImage?
//    @State private var showingImagePicker = false
//    
//    var body: some View {
//        VStack {
//            image?
//                .resizable()
//                .scaledToFit()
//            
//            Button("Select Image") {
//                showingImagePicker = true
//            }
//            
//            Button("Save Image") {
//                guard let inputImage = inputImage else { return }
//                
//                let imageSaver = ImageSaver()
//                imageSaver.writeToPhotoAlbum(image: inputImage)
//            }
//        }
//        .sheet(isPresented: $showingImagePicker) {
//            ImagePicker(image: $inputImage)
//        }
//        .onChange(of: inputImage) { _ in loadImage() }
//    }
//    
//    func loadImage() {
//        guard let inputImage = inputImage else { return }
//        image = Image(uiImage: inputImage)
//
////        UIImageWriteToSavedPhotosAlbum(inputImage, nil, nil, nil)
//    }
//}
