//
//  ImageSaver.swift
//  Instafilter
//
//  Created by 陈安冉 on 2023/1/1.
//

import UIKit

class ImageSaver: NSObject {
    func writeToPhotoAlbum(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveCompleted), nil)
    }
    
    @objc func saveCompleted(_ image: UIImage, disFinishSavingWithError error: Error?, contextInfo:
                             UnsafeRawPointer) {
        print("Save finished!")
    }
}
