//
//  InstafilterApp.swift
//  Instafilter
//
//  Created by 陈安冉 on 2022/12/31.
//

import SwiftUI

@main
struct InstafilterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
